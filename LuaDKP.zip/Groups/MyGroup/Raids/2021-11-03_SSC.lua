local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Caberyreason",
    [ 3] = "Eggnbacon",
    [ 4] = "Ejectoseato",
    [ 5] = "Eragoniz",
    [ 6] = "Imórtal",
    [ 7] = "Knockmeup",
    [ 8] = "Ksiadzropak",
    [ 9] = "Lamishra",
    [10] = "Malgeth",
    [11] = "Matoo",
    [12] = "Nattlys",
    [13] = "Ohgodfleas",
    [14] = "Opaq",
    [15] = "Rhagnor",
    [16] = "Saray",
    [17] = "Sint",
    [18] = "Eclipce",
    [19] = "Starscreåm",
    [20] = "Vendictus",
    [21] = "Vrilya",
    [22] = "Wampiix",
    [23] = "Youisyou",
    [24] = "Zabishii",
    [25] = "Ðizzy",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-03 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 623, timestamp = "2021-11-03 21:16", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2021-11-03 22:17", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2021-11-03 23:19", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-11-03 23:20", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 18, timestamp = "2021-11-03 21:16", item = 30054}, -- Soggypants : Ranger-General's Chestguard
--    {player =  9, timestamp = "2021-11-03 21:18", item = 30047}, -- Lamishra : Blackfathom Warbands
    {player = 18, timestamp = "2021-11-03 22:21", item = 30060}, -- Soggypants : Boots of Effortless Striking
    {player =  1, timestamp = "2021-11-03 23:22", item = 30239}, -- Animelove : Gloves of the Vanquished Champion
    {player = 24, timestamp = "2021-11-03 23:23", item = 30092}, -- Zabishii : Orca-Hide Boots
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
