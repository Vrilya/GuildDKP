local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bandobiitch",
    [ 3] = "Dexla",
    [ 4] = "Eggnbacon",
    [ 5] = "Eragoniz",
    [ 6] = "Eclipce",
    [ 7] = "Fauxxy",
    [ 8] = "Füryseth",
    [ 9] = "Knockmeup",
    [10] = "Ksiadzropak",
    [11] = "Lamishra",
    [12] = "Breadshadow",
    [13] = "Malgeth",
    [14] = "Mythria",
    [15] = "Nitugardy",
    [16] = "Opaq",
    [17] = "Palba",
    [18] = "Pillunsyöjä",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Sint",
    [22] = "Smellypaly",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-15 19:03", players = {1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2021-11-15 19:52", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2021-11-15 20:38", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-11-15 21:59", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 18, timestamp = "2021-11-15 19:54", item = 30091}, -- Pillunsyöjä : True-Aim Stalker Bands
    {player = 22, timestamp = "2021-11-15 19:56", item = 30239}, -- Smellypaly : Gloves of the Vanquished Champion
    {player = 14, timestamp = "2021-11-15 19:57", item = 30241}, -- Mythria : Gloves of the Vanquished Hero
    {player = 10, timestamp = "2021-11-15 20:39", item = 30100}, -- Ksiadzropak : Soul-Strider Boots
    {player = 11, timestamp = "2021-11-15 20:41", item = 30245}, -- Lamishra : Leggings of the Vanquished Champion
    {player =  9, timestamp = "2021-11-15 20:42", item = 30246}, -- Knockmeup : Leggings of the Vanquished Defender
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
