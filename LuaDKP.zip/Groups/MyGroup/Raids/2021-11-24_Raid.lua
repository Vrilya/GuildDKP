local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Dexla",
    [ 3] = "Eggnbacon",
    [ 4] = "Ejectoseato",
    [ 5] = "Eragoniz",
    [ 6] = "Eclipce",
    [ 7] = "Fauxxy",
    [ 8] = "Shovana",
    [ 9] = "Greyarrows",
    [10] = "Knockmeup",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Breadshadow",
    [14] = "Malgeth",
    [15] = "Mythria",
    [16] = "Nitugardy",
    [17] = "Omegazero",
    [18] = "Palba",
    [19] = "Pillunsyöjä",
    [20] = "Rhagnor",
    [21] = "Saray",
    [22] = "Sint",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Zenkaipowaah",
    [26] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-24 19:02", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26}},
    {boss = 623, timestamp = "2021-11-24 19:44", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26}},
    {boss = 624, timestamp = "2021-11-24 20:32", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26}},
    {boss = 625, timestamp = "2021-11-24 21:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26}},
    {boss = 626, timestamp = "2021-11-24 21:41", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26}},
    {boss = 901, timestamp = "2021-11-24 22:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,18,19,20,21,22,23,24,25,26}},
  },
  drops = {
    {player = 11, timestamp = "2021-11-24 19:43", item = 32516}, -- Ksiadzropak : Wraps of Purification
    {player =  2, timestamp = "2021-11-24 21:15", item = 30239}, -- Dexla : Gloves of the Vanquished Champion
    {player = 21, timestamp = "2021-11-24 21:17", item = 30095}, -- Saray : Fang of the Leviathan
    {player =  1, timestamp = "2021-11-24 21:43", item = 30245}, -- Animelove : Leggings of the Vanquished Champion
    {player =  2, timestamp = "2021-11-24 21:43", item = 30245}, -- Dexla : Leggings of the Vanquished Champion
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
