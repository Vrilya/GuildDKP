local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bopbop",
    [ 3] = "Farisha",
    [ 4] = "Fauxxy",
    [ 5] = "Fugee",
    [ 6] = "Shovana",
    [ 7] = "Greyarrows",
    [ 8] = "Husqie",
    [ 9] = "Knockmeup",
    [10] = "Ksiadzropak",
    [11] = "Lalapeja",
    [12] = "Lamishra",
    [13] = "Leafs",
    [14] = "Msyu",
    [15] = "Mythria",
    [16] = "Palba",
    [17] = "Pillunsyöjä",
    [18] = "Rhagnor",
    [19] = "Saray",
    [20] = "Shíryo",
    [21] = "Sint",
    [22] = "Siwex",
    [23] = "Vendictus",
    [24] = "Vrilya",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-29 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-11-29 22:39", players = {1,2,4,6,7,8,9,10,11,12,13,15,16,17,18,19,21,23,24,25}},
  },
  drops = {
    {player =  1, timestamp = "2021-11-29 22:25", item = 30028}, -- Animelove : Seventh Ring of the Tirisfalen
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
