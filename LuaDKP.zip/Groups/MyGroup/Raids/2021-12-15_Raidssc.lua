local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Ejectoseato",
    [ 6] = "Eclipce",
    [ 7] = "Fauxxy",
    [ 8] = "Greyarrows",
    [ 9] = "Husqie",
    [10] = "Jwarrior",
    [11] = "Knockmeup",
    [12] = "Ksiadzropak",
    [13] = "Lamishra",
    [15] = "Lunalea",
    [16] = "Malgeth",
    [17] = "Ninakraviz",
    [18] = "Nitugardy",
    [19] = "Nzothina",
    [20] = "Palba",
    [21] = "Pillunsyöjä",
    [22] = "Saray",
    [23] = "Shushi",
    [24] = "Sint",
    [25] = "Vrilya",
    [26] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-15 19:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,22,23,24,25,26}},
    {boss = 624, timestamp = "2021-12-15 19:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 625, timestamp = "2021-12-15 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 623, timestamp = "2021-12-15 20:06", players = {1,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,22,23,24,25,26}},
    {boss = 626, timestamp = "2021-12-15 20:52", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 627, timestamp = "2021-12-15 21:56", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 901, timestamp = "2021-12-15 21:58", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,21,22,23,24,25}},
  },
  drops = {
    {player = 11, timestamp = "2021-12-15 19:17", item = 30051}, -- Knockmeup : Idol of the Crescent Goddess
    {player =  9, timestamp = "2021-12-15 19:17", item = 30054}, -- Husqie : Ranger-General's Chestguard
    {player =  3, timestamp = "2021-12-15 19:36", item = 30061}, -- Breadshadow : Ancestral Ring of Conquest
    {player =  8, timestamp = "2021-12-15 20:08", item = 30091}, -- Greyarrows : True-Aim Stalker Bands
    {player = 22, timestamp = "2021-12-15 20:10", item = 30241}, -- Saray : Gloves of the Vanquished Hero
    {player =  6, timestamp = "2021-12-15 20:53", item = 30100}, -- Ethiel : Soul-Strider Boots
    {player = 26, timestamp = "2021-12-15 20:56", item = 30247}, -- Ælizabeth : Leggings of the Vanquished Hero
    {player = 18, timestamp = "2021-12-15 20:57", item = 30247}, -- Nitugardy : Leggings of the Vanquished Hero
    {player = 10, timestamp = "2021-12-15 20:58", item = 30247}, -- Jwarrior : Leggings of the Vanquished Hero
    {player = 21, timestamp = "2021-12-15 21:57", item = 30081}, -- Pillunsyöjä : Warboots of Obliteration
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
