local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Ejectoseato",
    [ 6] = "Eclipce",
    [ 7] = "Fauxxy",
    [ 8] = "Husqie",
    [ 9] = "Jwarrior",
    [10] = "Knockmeup",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Lunalea",
    [14] = "Malgeth",
    [15] = "Mythria",
    [16] = "Nzothina",
    [17] = "Palba",
    [18] = "Pillunsyöjä",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Sint",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-20 18:57", players = {1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2021-12-20 19:54", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2021-12-20 20:20", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2021-12-20 20:58", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-12-20 22:07", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 23, timestamp = "2021-12-20 19:55", item = 29947}, -- Vrilya : Gloves of the Searing Grip
    {player = 20, timestamp = "2021-12-20 20:02", item = 30024}, -- Saray : Mantle of the Elven Kings
    {player =  3, timestamp = "2021-12-20 20:22", item = 30249}, -- Breadshadow : Pauldrons of the Vanquished Defender
    {player = 24, timestamp = "2021-12-20 20:22", item = 30248}, -- Zabishii : Pauldrons of the Vanquished Champion
    {player =  1, timestamp = "2021-12-20 20:59", item = 32267}, -- Animelove : Boots of the Resilient
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
