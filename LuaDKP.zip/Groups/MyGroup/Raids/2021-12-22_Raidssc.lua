local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Amadena",
    [ 2] = "Andiet",
    [ 3] = "Animelove",
    [ 4] = "Bagts",
    [ 5] = "Breadshadow",
    [ 6] = "Doomhart",
    [ 7] = "Eclipce",
    [ 8] = "Ejectoseato",
    [ 9] = "Fåt",
    [10] = "Gavun",
    [11] = "Shovana",
    [12] = "Husqie",
    [13] = "Ksiadzropak",
    [14] = "Lamishra",
    [15] = "Lithaele",
    [16] = "Livere",
    [17] = "Malgeth",
    [18] = "Nüwa",
    [19] = "Pillunsyöjä",
    [20] = "Redyo",
    [21] = "Rhagnor",
    [22] = "Shadowspan",
    [23] = "Skyfeather",
    [24] = "Sotella",
    [25] = "Strazda",
    [26] = "Vrilya",
    [27] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-22 19:00", players = {2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,25,26,27}},
    {boss = 623, timestamp = "2021-12-22 19:20", players = {2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 624, timestamp = "2021-12-22 19:50", players = {2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 625, timestamp = "2021-12-22 20:50", players = {2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 626, timestamp = "2021-12-22 21:14", players = {2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 627, timestamp = "2021-12-22 22:00", players = {1,2,3,4,5,6,7,8,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 901, timestamp = "2021-12-22 22:01", players = {1,2,3,4,5,6,7,8,10,11,12,14,15,16,17,18,19,20,21,22,23,24,25,26,27}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
