local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Andiet",
    [ 2] = "Animelove",
    [ 3] = "Aramys",
    [ 4] = "Bagts",
    [ 5] = "Breadshadow",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Gavun",
    [ 9] = "Husqie",
    [10] = "Hårig",
    [11] = "Jeani",
    [12] = "Jwarrior",
    [13] = "Katlay",
    [14] = "Ksiadzropak",
    [15] = "Lamishra",
    [16] = "Lunalea",
    [17] = "Malgeth",
    [18] = "Palba",
    [19] = "Pillunsyöjä",
    [20] = "Rhagnor",
    [21] = "Saray",
    [22] = "Shushi",
    [23] = "Smolpala",
    [24] = "Vendictus",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-29 19:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,17,18,19,20,21,22,24,25}},
    {boss = 623, timestamp = "2021-12-29 19:28", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2021-12-29 19:45", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2021-12-29 20:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2021-12-29 20:50", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 627, timestamp = "2021-12-29 21:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 628, timestamp = "2021-12-29 22:26", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 903, timestamp = "2021-12-29 22:27", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-12-29 22:30", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
--    {player =  4, timestamp = "2021-12-29 20:11", item = 30241}, -- Bagts : Gloves of the Vanquished Hero
    {player = 11, timestamp = "2021-12-29 22:28", item = 30243}, -- Jeani : Helm of the Vanquished Defender
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
