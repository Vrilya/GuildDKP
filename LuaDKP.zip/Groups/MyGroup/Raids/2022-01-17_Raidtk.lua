local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Brenton",
    [ 5] = "Doomhart",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Gavun",
    [ 9] = "Hánna",
    [10] = "Jwarrior",
    [11] = "Knockmeup",
    [12] = "Ksiadzropak",
    [13] = "Lamishra",
    [14] = "Locktorius",
    [15] = "Malgeth",
    [16] = "Mythria",
    [17] = "Onionring",
    [18] = "Palba",
    [19] = "Palypoes",
    [20] = "Rhagnor",
    [21] = "Saray",
    [22] = "Shushi",
    [23] = "Sint",
    [24] = "Tidanbo",
    [25] = "Volrik",
    [26] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-17 19:01", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,19,20,21,22,23,24,25,26}},
    {boss = 732, timestamp = "2022-01-17 19:22", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,19,20,21,22,23,24,25,26}},
    {boss = 733, timestamp = "2022-01-17 21:23", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 901, timestamp = "2022-01-17 21:23", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
  },
  drops = {
    {player = 16, timestamp = "2022-01-17 19:33", item = 30026}, -- Mythria : Bands of the Celestial Archer
    {player =  5, timestamp = "2022-01-17 21:25", item = 29989}, -- Doomhart : Sunshower Light Cloak
    {player = 13, timestamp = "2022-01-17 21:28", item = 32405}, -- Lamishra : Verdant Sphere
    {player =  2, timestamp = "2022-01-17 21:29", item = 30238}, -- Bagts : Chestguard of the Vanquished Hero
    {player = 19, timestamp = "2022-01-17 21:30", item = 30236}, -- Palypoes : Chestguard of the Vanquished Champion
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
