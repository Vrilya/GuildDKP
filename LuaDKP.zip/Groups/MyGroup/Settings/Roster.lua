local _, ADDON = ...

------------------------------------------------------------

-- Console/Definitions.lua:
-- 1 = Druid, 2 = Hunter, 3 = Mage, 4 = Paladin, 5 = Priest, 6 = Rogue, 7 = Shaman, 8 = Warlock, 9 = Warrior
-- 1 = Tank, 2 = Melee, 3 = Ranged, 4 = Heal

------------------------------------------------------------

local roster = {
--["PlayerName"] = {xclass = 1, role = 1, nickname = "NameWithoutSpecialCharacters"},
["Animelove"] = {xclass = 4, role = 1, nickname = "Animelove"},
["Lethander"] = {xclass = 4, role = 2, nickname = "Lethander"},
["Lalapeja"] = {xclass = 4, role = 1, nickname = "Lalapeja"},
["Breadshadow"] = {xclass = 1, role = 2, nickname = "Breadshadow"},
["Vrilya"] = {xclass = 9, role = 1, nickname = "Vrilya"},
["Knockmeup"] = {xclass = 1, role = 4, nickname = "Knockmeup"},
["Zabishii"] = {xclass = 7, role = 4, nickname = "Zabishii"},
["Ejectoseato"] = {xclass = 9, role = 2, nickname = "Ejectoseato"},
["Carebeared"] = {xclass = 1, role = 2, nickname = "Carebeared"},
["Daffke"] = {xclass = 6, role = 2, nickname = "Daffke"},
["Eragoniz"] = {xclass = 7, role = 2, nickname = "Eragoniz"},
["Opaq"] = {xclass = 1, role = 2, nickname = "Opaq"},
["Smellypaly"] = {xclass = 4, role = 4, nickname = "Smellypaly"},
["Vendictus"] = {xclass = 5, role = 3, nickname = "Vendictus"},
["Soggypants"] = {xclass = 2, role = 3, nickname = "Soggypants"},
["Ethiel"] = {xclass = 1, role = 4, nickname = "Ethiel"},
["Mythria"] = {xclass = 2, role = 3, nickname = "Mythria"},
["Orama"] = {xclass = 2, role = 3, nickname = "Orama"},
["Rhagnor"] = {xclass = 2, role = 3, nickname = "Rhagnor"},
["Sint"] = {xclass = 5, role = 3, nickname = "Sint"},
["Nattlys"] = {xclass = 5, role = 4, nickname = "Nattlys"},
["Eggnbacon"] = {xclass = 3, role = 3, nickname = "Eggnbacon"},
["Saray"] = {xclass = 3, role = 3, nickname = "Saray"},
["Malgeth"] = {xclass = 8, role = 3, nickname = "Malgeth"},
["Ælizabeth"] = {xclass = 8, role = 3, nickname = "Aelizabeth"},
["Lamishra"] = {xclass = 7, role = 3, nickname = "Lamishra"},
["Caberyreason"] = {xclass = 1, role = 3, nickname = "Caberyreason"},
["Ksiadzropak"] = {xclass = 5, role = 4, nickname = "Ksiadzropak"},
["Eclipce"] = {xclass = 5, role = 4, nickname = "Eclipce"},
["Fêar"] = {xclass = 8, role = 3, nickname = "Fear"},
["Wampiix"] = {xclass = 5, role = 4, nickname = "Wampiix"},
["Matoo"] = {xclass = 3, role = 3, nickname = "Matoo"},
["Palba"] = {xclass = 5, role = 4, nickname = "Palba"},
["Pillunsyöjä"] = {xclass = 9, role = 2, nickname = "Pillunsyoja"},
["Totemaizer"] = {xclass = 7, role = 3, nickname = "Totemaizer"},
["Imórtal"] = {xclass = 4, role = 1, nickname = "Imortal"},
["Dexla"] = {xclass = 6, role = 2, nickname = "Dexla"},
["Ládyhawke"] = {xclass = 5, role = 4, nickname = "Ládyhawke"},
["Nitugardy"] = {xclass = 3, role = 3, nickname = "Nitugardy"},
["Fauxxy"] = {xclass = 1, role = 3, nickname = "Fauxxy"},
["Shovana"] = {xclass = 3, role = 3, nickname = "Shovana"},
["Battman"] = {xclass = 3, role = 3, nickname = "Battman"},
["Hánna"] = {xclass = 4, role = 4, nickname = "Hánna"},
["Bagts"] = {xclass = 3, role = 3, nickname = "Bagts"},
["Shushi"] = {xclass = 5, role = 4, nickname = "Shushi"},
["Jwarrior"] = {xclass = 9, role = 2, nickname = "Jwarrior"},
["Iater"] = {xclass = 1, role = 4, nickname = "Iater"},
["Husqie"] = {xclass = 2, role = 3, nickname = "Husqie"},
["Jeani"] = {xclass = 5, role = 4, nickname = "Jeani"},
["Gavun"] = {xclass = 6, role = 2, nickname = "Gavun"},
["Palypoes"] = {xclass = 4, role = 2, nickname = "Palypoes"},
["Volrik"] = {xclass = 3, role = 3, nickname = "Volrik"},
["Locktorius"] = {xclass = 8, role = 3, nickname = "Locktorius"},
["Brenton"] = {xclass = 8, role = 3, nickname = "Brenton"},
["Greyarrows"] = {xclass = 2, role = 3, nickname = "Greyarrows"},
["Doomhart"] = {xclass = 4, role = 4, nickname = "Doomhart"},
["Onionring"] = {xclass = 3, role = 3, nickname = "Onionring"},
["Tidanbo"] = {xclass = 9, role = 2, nickname = "Tidanbo"},
}

------------------------------------------------------------

-- export tables
ADDON.InitGroup.Roster = roster
