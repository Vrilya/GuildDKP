local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Ejectoseato",
    [ 2] = "Knockmeup",
    [ 3] = "Opaq",
    [ 4] = "Vrilya",
    [ 5] = "Animelove",
    [ 6] = "Lamishra",
    [ 7] = "Saray",
    [ 8] = "Rhagnor",
    [ 9] = "Palba",
    [ 10] = "Eclipce",
    [ 11] = "Ælizabeth",
    [ 12] = "Zabishii",
    [ 13] = "Mythria",
    [ 14] = "Eragoniz",
    [ 15] = "Carebeared",
    [ 16] = "Daffke",
    [ 17] = "Vendictus",
	[ 18] = "Caberyreason",
	[ 19] = "Sint",
	[ 20] = "Nattlys",
	[ 21] = "Eggnbacon",
	[ 22] = "Malgeth",
  },
  kills = {
     {boss = 900, timestamp = "2021-11-01 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22}},
     {boss = 623, timestamp = "2021-11-01 20:51", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22}},
     {boss = 901, timestamp = "2021-11-01 23:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22}},
    },
  drops = {
    {player =  2, timestamp = "2021-11-01 20:53", item = 30664}, -- Knockmeup : Living Root of the Wildheart
    {player =  14, timestamp = "2021-11-01 20:55", item = 30055}, -- Eragoniz : Shoulderpads of the Stranger
    {player =  1, timestamp = "2021-11-01 21:11", item = 30022}, -- Ejectoseato : Pendant of the Perilous
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
