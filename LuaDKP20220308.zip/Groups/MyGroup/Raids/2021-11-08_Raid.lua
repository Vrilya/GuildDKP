local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Caberyreason",
    [ 3] = "Eggnbacon",
    [ 4] = "Ejectoseato",
    [ 5] = "Eragoniz",
    [ 6] = "Fêar",
    [ 7] = "Imórtal",
    [ 8] = "Knockmeup",
    [ 9] = "Ksiadzropak",
    [10] = "Lamishra",
    [11] = "Malgeth",
    [12] = "Mythria",
    [13] = "Ohgodfleas",
    [14] = "Opaq",
    [15] = "Orama",
    [16] = "Palba",
    [17] = "Pillunsyöjä",
    [18] = "Rhagnor",
    [19] = "Saray",
    [20] = "Sint",
    [21] = "Smellypaly",
    [22] = "Eclipce",
    [23] = "Totemaizer",
    [24] = "Vendictus",
    [25] = "Vrilya",
    [26] = "Wampiix",
    [27] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-08 18:59", players = {1,2,3,4,5,7,8,9,10,11,12,14,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 626, timestamp = "2021-11-08 19:59", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 901, timestamp = "2021-11-08 22:05", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,16,17,18,19,20,21,22,23,24,25,26,27}},
  },
  drops = {
    {player = 10, timestamp = "2021-11-08 20:02", item = 30663}, -- Lamishra : Fathom-Brooch of the Tidewalker
    {player =  3, timestamp = "2021-11-08 20:04", item = 30247}, -- Eggnbacon : Leggings of the Vanquished Hero
    {player = 14, timestamp = "2021-11-08 20:05", item = 30246}, -- Opaq : Leggings of the Vanquished Defender
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
