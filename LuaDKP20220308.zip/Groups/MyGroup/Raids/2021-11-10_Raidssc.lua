local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Daffke",
    [ 3] = "Dexla",
    [ 4] = "Eggnbacon",
    [ 5] = "Ejectoseato",
    [ 6] = "Eragoniz",
    [ 7] = "Fauxxy",
    [ 8] = "Handygoi",
    [ 9] = "Imórtal",
    [10] = "Knockmeup",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Malgeth",
    [14] = "Matoo",
    [15] = "Mythria",
    [16] = "Noaki",
    [17] = "Opaq",
    [18] = "Palba",
    [19] = "Pillunsyöjä",
    [20] = "Rhagnor",
    [21] = "Saray",
    [22] = "Sint",
    [23] = "Smellypaly",
    [24] = "Vrilya",
    [25] = "Wampiix",
    [26] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-10 19:00", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 623, timestamp = "2021-11-10 20:29", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 624, timestamp = "2021-11-10 22:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-11-10 19:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player =  5, timestamp = "2021-11-10 20:27", item = 30055}, -- Ejectoseato : Shoulderpads of the Stranger
    {player = 17, timestamp = "2021-11-10 20:28", item = 30664}, -- Opaq : Living Root of the Wildheart
    {player = 17, timestamp = "2021-11-10 20:37", item = 30021}, -- Opaq : Wildfury Greatstaff
    {player = 14, timestamp = "2021-11-10 22:08", item = 30067}, -- Matoo : Velvet Boots of the Guardian
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
