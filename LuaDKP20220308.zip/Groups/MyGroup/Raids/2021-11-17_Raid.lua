local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Dexla",
    [ 3] = "Ejectoseato",
    [ 4] = "Eragoniz",
    [ 5] = "Eclipce",
    [ 6] = "Jvd",
    [ 7] = "Knockmeup",
    [ 8] = "Ksiadzropak",
    [ 9] = "Lamishra",
    [10] = "Breadshadow",
    [11] = "Malgeth",
    [12] = "Mythria",
    [13] = "Nitugardy",
    [14] = "Opaq",
    [15] = "Palba",
    [16] = "Pillunsyöjä",
    [17] = "Rhagnor",
    [18] = "Saray",
    [19] = "Sint",
    [20] = "Vrilya",
    [21] = "Zabishii",
    [22] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-17 19:01", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22}},
    {boss = 901, timestamp = "2021-11-17 23:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
