local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Agraynal",
    [ 2] = "Animelove",
    [ 3] = "Asdrexiar",
    [ 4] = "Eggnbacon",
    [ 5] = "Ejectoseato",
    [ 6] = "Eragoniz",
    [ 7] = "Eclipce",
    [ 8] = "Shovana",
    [ 9] = "Greyarrows",
    [10] = "Knockmeup",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Breadshadow",
    [14] = "Ládyhawke",
    [15] = "Malgeth",
    [16] = "Mythria",
    [17] = "Nitugardy",
    [18] = "Palba",
    [19] = "Pillunsyöjä",
    [20] = "Rhagnor",
    [21] = "Saray",
    [22] = "Sint",
    [23] = "Vendictus",
    [24] = "Vrilya",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-11-22 18:55", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 623, timestamp = "2021-11-22 19:34", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2021-11-22 20:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2021-11-22 20:50", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2021-11-22 21:29", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 627, timestamp = "2021-11-22 22:32", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-11-22 22:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player =  7, timestamp = "2021-11-22 19:33", item = 30051}, -- Ethiel : Idol of the Crescent Goddess
    {player = 19, timestamp = "2021-11-22 19:33", item = 30055}, -- Pillunsyöjä : Shoulderpads of the Stranger
    {player = 19, timestamp = "2021-11-22 20:07", item = 30059}, -- Pillunsyöjä : Choker of Animalistic Fury
    {player = 12, timestamp = "2021-11-22 20:52", item = 30239}, -- Lamishra : Gloves of the Vanquished Champion
    {player = 17, timestamp = "2021-11-22 20:52", item = 30241}, -- Nitugardy : Gloves of the Vanquished Hero
    {player = 15, timestamp = "2021-11-22 21:31", item = 30247}, -- Malgeth : Leggings of the Vanquished Hero
    {player = 13, timestamp = "2021-11-22 22:34", item = 30098}, -- Lethander : Razor-Scale Battlecloak
    {player = 13, timestamp = "2021-11-22 22:34", item = 30068}, -- Lethander : Girdle of the Tidal Call
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
