local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Battman",
    [ 3] = "Eggnbacon",
    [ 4] = "Eclipce",
    [ 5] = "Shovana",
    [ 6] = "Greyarrows",
    [ 8] = "Jeani",
    [ 9] = "Jwarrior",
    [10] = "Knockmeup",
    [11] = "Ksiadzropak",
    [12] = "Lalapeja",
    [13] = "Lamishra",
    [14] = "Breadshadow",
    [15] = "Malgeth",
    [16] = "Mythria",
    [17] = "Mållgan",
    [18] = "Ninakraviz",
    [19] = "Nitugardy",
    [20] = "Palba",
    [21] = "Rhagnor",
    [22] = "Rolce",
    [23] = "Saray",
    [24] = "Sint",
    [25] = "Vendictus",
    [26] = "Vrilya",
    [27] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-01 18:54", players = {1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,18,19,20,21,23,24,26,27}},
    {boss = 623, timestamp = "2021-12-01 19:26", players = {1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27}},
    {boss = 624, timestamp = "2021-12-01 19:58", players = {1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,26,27}},
    {boss = 625, timestamp = "2021-12-01 21:13", players = {1,2,3,4,5,6,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 626, timestamp = "2021-12-01 21:46", players = {1,2,3,4,5,6,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 901, timestamp = "2021-12-01 22:16", players = {1,2,3,4,5,6,8,9,10,11,12,13,15,16,17,18,19,20,21,23,24,25,26,27}},
  },
  drops = {
    {player = 27, timestamp = "2021-12-01 19:26", item = 30049}, -- Ælizabeth : Fathomstone
    {player = 10, timestamp = "2021-12-01 19:59", item = 30062}, -- Knockmeup : Grove-Bands of Remulos
    {player =  5, timestamp = "2021-12-01 20:01", item = 30067}, -- Gingergem : Velvet Boots of the Guardian
    {player = 12, timestamp = "2021-12-01 21:14", item = 30096}, -- Lalapeja : Girdle of the Invulnerable
    {player = 26, timestamp = "2021-12-01 21:15", item = 30240}, -- Vrilya : Gloves of the Vanquished Defender
    {player = 12, timestamp = "2021-12-01 21:48", item = 30245}, -- Lalapeja : Leggings of the Vanquished Champion
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
