local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Doomhart",
    [ 3] = "Ejectoseato",
    [ 4] = "Eclipce",
    [ 5] = "Fauxxy",
    [ 6] = "Gassygirl",
    [ 7] = "Shovana",
    [ 8] = "Greyarrows",
    [ 9] = "Husqie",
    [10] = "Jwarrior",
    [11] = "Knockmeup",
    [12] = "Ksiadzropak",
    [13] = "Lamishra",
    [14] = "Breadshadow",
    [15] = "Malgeth",
    [16] = "Mythria",
    [17] = "Nitugardy",
    [18] = "Palba",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Sint",
    [22] = "Vendictus",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-06 19:00", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2021-12-06 20:12", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 903, timestamp = "2021-12-06 20:12", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2021-12-06 20:53", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 903, timestamp = "2021-12-06 20:53", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2021-12-06 22:06", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 903, timestamp = "2021-12-06 22:06", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-12-06 23:00", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 18, timestamp = "2021-12-06 20:13", item = 29923}, -- Palba : Talisman of the Sun King
    {player =  1, timestamp = "2021-12-06 20:15", item = 29925}, -- Animelove : Phoenix-Wing Cloak
    {player =  4, timestamp = "2021-12-06 20:54", item = 29984}, -- Ethiel : Girdle of Zaetar
    {player = 19, timestamp = "2021-12-06 20:55", item = 30250}, -- Rhagnor : Pauldrons of the Vanquished Hero
    {player = 23, timestamp = "2021-12-06 20:56", item = 30249}, -- Vrilya : Pauldrons of the Vanquished Defender
    {player = 17, timestamp = "2021-12-06 21:18", item = 30024}, -- Nitugardy : Mantle of the Elven Kings
    {player =  3, timestamp = "2021-12-06 22:07", item = 29950}, -- Ejectoseato : Greaves of the Bloodwarder
    {player = 12, timestamp = "2021-12-06 22:07", item = 29981}, -- Ksiadzropak : Ethereum Life-Staff
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
