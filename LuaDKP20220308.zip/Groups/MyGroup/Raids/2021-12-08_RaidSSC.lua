local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Breadshadow",
    [ 3] = "Lung",
    [ 4] = "Ejectoseato",
    [ 5] = "Vrilya",
    [ 6] = "Greyarrows",
    [ 7] = "Husqie",
    [ 8] = "Mythria",
    [ 9] = "Bagts",
    [10] = "Saray",
    [11] = "Shovana",
    [12] = "Sint",
    [13] = "Vendictus",
    [14] = "Lamishra",
    [15] = "Jwarrior",
    [16] = "Malgeth",
    [17] = "Ælizabeth",
    [18] = "Bamsehop",
    [19] = "Pillunsyöjä",
    [20] = "Eclipce",
    [21] = "Knockmeup",
    [22] = "Pietmondrian",
    [23] = "Smolpala",
    [24] = "Ksiadzropak",
    [25] = "Palba",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-08 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 623, timestamp = "2021-12-08 20:23", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2021-12-08 20:53", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2021-12-08 22:06", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-12-08 23:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
  },
  drops = {
    {player = 14, timestamp = "2021-12-08 20:25", item = 30056}, -- Lamishra : Robe of Hateful Echoes
    {player = 20, timestamp = "2021-12-08 20:25", item = 32516}, -- Ethiel : Wraps of Purification
--    {player =  9, timestamp = "2021-12-08 21:30", item = 30095}, -- Bagts : Fang of the Leviathan
    {player = 20, timestamp = "2021-12-08 22:05", item = 30100}, -- Ethiel : Soul-Strider Boots
    {player = 13, timestamp = "2021-12-08 22:05", item = 30246}, -- Vendictus : Leggings of the Vanquished Defender
    {player =  5, timestamp = "2021-12-08 22:05", item = 30246}, -- Vrilya : Leggings of the Vanquished Defender
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
