local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Centaurea",
    [ 4] = "Doomhart",
    [ 5] = "Ejectoseato",
    [ 6] = "Eclipce",
    [ 7] = "Greyarrows",
    [ 8] = "Husqie",
    [ 9] = "Jwarrior",
    [10] = "Ksiadzropak",
    [11] = "Lamishra",
    [12] = "Breadshadow",
    [13] = "Malgeth",
    [14] = "Mythria",
    [15] = "Niteeloser",
    [16] = "Nitugardy",
    [17] = "Palba",
    [18] = "Pillunsyöjä",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Sushaman",
    [23] = "Vendictus",
    [24] = "Vrilya",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-13 19:02", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2021-12-13 19:43", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2021-12-13 20:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2021-12-13 20:49", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-12-13 21:59", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 19, timestamp = "2021-12-13 19:45", item = 29949}, -- Rhagnor : Arcanite Steam-Pistol
    {player = 18, timestamp = "2021-12-13 20:50", item = 29950}, -- Pillunsyöjä : Greaves of the Bloodwarder
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
