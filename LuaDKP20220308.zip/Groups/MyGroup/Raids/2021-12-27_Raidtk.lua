local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Agraynal",
    [ 2] = "Animelove",
    [ 3] = "Bagts",
    [ 4] = "Breadshadow",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Hopelêss",
    [ 9] = "Husqie",
    [10] = "Iater",
    [11] = "Jwarrior",
    [12] = "Kaptenpoke",
    [13] = "Ksiadzropak",
    [14] = "Lamishra",
    [15] = "Liying",
    [16] = "Malgeth",
    [17] = "Mythria",
    [18] = "Palba",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Smolpala",
    [22] = "Trixti",
    [23] = "Trylletrine",
    [24] = "Vendictus",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2021-12-27 18:56", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2021-12-27 19:29", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2021-12-27 19:51", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2021-12-27 20:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2021-12-27 22:10", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 17, timestamp = "2021-12-27 19:53", item = 30250}, -- Mythria : Pauldrons of the Vanquished Hero
    {player =  3, timestamp = "2021-12-27 19:53", item = 30250}, -- Bagts : Pauldrons of the Vanquished Hero
    {player =  5, timestamp = "2021-12-27 19:54", item = 30619}, -- Eclipce : Fel Reaver's Piston
--    {player =  6, timestamp = "2021-12-27 20:09", item = 30446}, -- Ejectoseato : Solarian's Sapphire
    {player = 15, timestamp = "2021-12-27 20:11", item = 29982}, -- Liying : Wand of the Forgotten Star
    {player = 10, timestamp = "2021-12-27 22:11", item = 29923}, -- Iater : Talisman of the Sun King
    {player = 10, timestamp = "2021-12-27 22:11", item = 30029}, -- Iater : Bark-Gloves of Ancient Wisdom
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
