local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Eclipce",
    [ 6] = "Fauxxy",
    [ 7] = "Gavun",
    [ 8] = "Hobermallow",
    [ 9] = "Iater",
    [10] = "Jeani",
    [11] = "Jwarrior",
    [12] = "Knockmeup",
    [13] = "Ksiadzropak",
    [14] = "Lamishra",
    [15] = "Malgeth",
    [16] = "Monkyman",
    [17] = "Mystas",
    [18] = "Mythria",
    [19] = "Omeletta",
    [20] = "Palba",
    [21] = "Rhagnor",
    [22] = "Slackotolij",
    [23] = "Theonedp",
    [24] = "Vrilya",
    [25] = "Zofija",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-03 18:59", players = {1,2,3,4,5,6,7,8,9,10,11,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2022-01-03 19:29", players = {1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2022-01-03 19:54", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2022-01-03 20:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 733, timestamp = "2022-01-03 21:03", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 903, timestamp = "2022-01-03 21:04", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-01-03 21:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player =  2, timestamp = "2022-01-03 19:30", item = 29922}, -- Bagts : Band of Al'ar
    {player =  9, timestamp = "2022-01-03 19:55", item = 29984}, -- Iater : Girdle of Zaetar
    {player = 12, timestamp = "2022-01-03 19:57", item = 30249}, -- Knockmeup : Pauldrons of the Vanquished Defender
    {player = 20, timestamp = "2022-01-03 20:05", item = 30026}, -- Palba : Bands of the Celestial Archer
    {player =  5, timestamp = "2022-01-03 20:11", item = 29981}, -- Eclipce : Ethereum Life-Staff
    {player =  6, timestamp = "2022-01-03 21:07", item = 30237}, -- Fauxxy : Chestguard of the Vanquished Defender
    {player = 24, timestamp = "2022-01-03 21:08", item = 30237}, -- Vrilya : Chestguard of the Vanquished Defender
    {player =  4, timestamp = "2022-01-03 21:10", item = 32405}, -- Doomhart : Verdant Sphere
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
