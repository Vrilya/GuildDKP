local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Eragoniz",
    [ 8] = "Gavun",
    [ 9] = "Husqie",
    [10] = "Iater",
    [11] = "Jeani",
    [12] = "Jwarrior",
    [13] = "Ksiadzropak",
    [14] = "Lamishra",
    [15] = "Lilltossen",
    [16] = "Lunalea",
    [17] = "Malgeth",
    [18] = "Mythria",
    [19] = "Ninakraviz",
    [20] = "Palba",
    [21] = "Rhagnor",
    [22] = "Shushi",
    [23] = "Stygging",
    [24] = "Tidanbo",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-05 18:58", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25}},
    {boss = 624, timestamp = "2022-01-05 19:34", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2022-01-05 21:53", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2022-01-05 22:13", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 627, timestamp = "2022-01-05 22:33", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-01-05 22:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 14, timestamp = "2022-01-05 19:16", item = 30049}, -- Lamishra : Fathomstone
    {player =  4, timestamp = "2022-01-05 19:16", item = 33055}, -- Doomhart : Band of Vile Aggression
    {player = 13, timestamp = "2022-01-05 19:36", item = 30665}, -- Ksiadzropak : Earring of Soulful Meditation
    {player =  3, timestamp = "2022-01-05 21:39", item = 30021}, -- Breadshadow : Wildfury Greatstaff
    {player =  8, timestamp = "2022-01-05 21:55", item = 30239}, -- Gavun : Gloves of the Vanquished Champion
    {player =  7, timestamp = "2022-01-05 21:56", item = 30239}, -- Eragoniz : Gloves of the Vanquished Champion
    {player =  7, timestamp = "2022-01-05 22:14", item = 30245}, -- Eragoniz : Leggings of the Vanquished Champion
    {player =  6, timestamp = "2022-01-05 22:15", item = 30246}, -- Ejectoseato : Leggings of the Vanquished Defender
    {player = 12, timestamp = "2022-01-05 22:35", item = 30082}, -- Jwarrior : Talon of Azshara
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
