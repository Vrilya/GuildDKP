local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Eragoniz",
    [ 8] = "Fauxxy",
    [ 9] = "Finkleblitz",
    [10] = "Gavun",
    [11] = "Greyarrows",
    [12] = "Husqie",
    [13] = "Jeani",
    [14] = "Jwarrior",
    [15] = "Ksiadzropak",
    [16] = "Lamishra",
    [17] = "Locktorius",
    [18] = "Malgeth",
    [19] = "Mythria",
    [20] = "Palypoes",
    [21] = "Punainen",
    [22] = "Rhagnor",
    [23] = "Saray",
    [24] = "Thdarkone",
    [25] = "Volrik",
    [26] = "Vrilya",
    [27] = "Zabishii",
    [28] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-10 19:02", players = {1,2,3,4,5,6,7,8,12,13,14,15,16,17,18,19,20,22,23,25,26,27,28}},
    {boss = 730, timestamp = "2022-01-10 19:27", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,22,23,25,26,27,28}},
    {boss = 731, timestamp = "2022-01-10 19:46", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,22,23,25,26,27,28}},
    {boss = 732, timestamp = "2022-01-10 20:07", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,22,23,25,26,27,28}},
    {boss = 733, timestamp = "2022-01-10 21:16", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,22,23,25,26,27,28}},
    {boss = 901, timestamp = "2022-01-10 22:17", players = {1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,18,19,21,22,23,24,26,27,28}},
  },
  drops = {
    {player = 10, timestamp = "2022-01-10 19:28", item = 29949}, -- Gavun : Arcanite Steam-Pistol
    {player = 23, timestamp = "2022-01-10 19:48", item = 30250}, -- Saray : Pauldrons of the Vanquished Hero
    {player = 17, timestamp = "2022-01-10 19:48", item = 30250}, -- Locktorius : Pauldrons of the Vanquished Hero
    {player =  1, timestamp = "2022-01-10 19:50", item = 32515}, -- Animelove : Wristguards of Determination
    {player = 13, timestamp = "2022-01-10 20:11", item = 29981}, -- Jeani : Ethereum Life-Staff
    {player = 22, timestamp = "2022-01-10 21:18", item = 30238}, -- Rhagnor : Chestguard of the Vanquished Hero
    {player = 12, timestamp = "2022-01-10 21:19", item = 30238}, -- Husqie : Chestguard of the Vanquished Hero
    {player = 19, timestamp = "2022-01-10 21:19", item = 29994}, -- Mythria : Thalassian Wildercloak
    {player =  5, timestamp = "2022-01-10 21:20", item = 29990}, -- Eclipce : Crown of the Sun
    {player = 22, timestamp = "2022-01-10 21:22", item = 32405}, -- Rhagnor : Verdant Sphere
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
