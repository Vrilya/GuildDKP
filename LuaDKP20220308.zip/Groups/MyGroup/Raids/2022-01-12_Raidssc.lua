local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Brenton",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Eragoniz",
    [ 8] = "Fauxxy",
    [ 9] = "Gavun",
    [10] = "Husqie",
    [11] = "Hánna",
    [12] = "Jeani",
    [13] = "Jwarrior",
    [14] = "Knockmeup",
    [15] = "Ksiadzropak",
    [16] = "Lamishra",
    [17] = "Locktorius",
    [18] = "Malgeth",
    [19] = "Mythria",
    [20] = "Palypoes",
    [21] = "Rhagnor",
    [22] = "Volrik",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-12 19:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25}},
    {boss = 623, timestamp = "2022-01-12 19:24", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2022-01-12 19:34", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 628, timestamp = "2022-01-12 19:55", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2022-01-12 20:19", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2022-01-12 20:38", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 627, timestamp = "2022-01-12 21:03", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2022-01-12 21:45", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2022-01-12 22:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-01-12 22:18", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 11, timestamp = "2022-01-12 19:25", item = 30047}, -- Hánna : Blackfathom Warbands
    {player =  3, timestamp = "2022-01-12 19:26", item = 33055}, -- Breadshadow : Band of Vile Aggression
    {player = 11, timestamp = "2022-01-12 19:36", item = 30065}, -- Hánna : Glowing Breastplate of Truth
    {player = 14, timestamp = "2022-01-12 19:58", item = 30108}, -- Knockmeup : Lightfathom Scepter
    {player =  1, timestamp = "2022-01-12 19:59", item = 30242}, -- Animelove : Helm of the Vanquished Champion
    {player =  9, timestamp = "2022-01-12 19:59", item = 30242}, -- Gavun : Helm of the Vanquished Champion
    {player = 13, timestamp = "2022-01-12 20:20", item = 30627}, -- Jwarrior : Tsunami Talisman
    {player = 15, timestamp = "2022-01-12 20:21", item = 30240}, -- Ksiadzropak : Gloves of the Vanquished Defender
    {player = 22, timestamp = "2022-01-12 20:40", item = 30626}, -- Volrik : Sextant of Unstable Currents
    {player = 11, timestamp = "2022-01-12 20:41", item = 30245}, -- Hánna : Leggings of the Vanquished Champion
    {player = 15, timestamp = "2022-01-12 20:42", item = 30246}, -- Ksiadzropak : Leggings of the Vanquished Defender
    {player = 22, timestamp = "2022-01-12 22:16", item = 30250}, -- Volrik : Pauldrons of the Vanquished Hero
    {player =  4, timestamp = "2022-01-12 22:17", item = 30250}, -- Brenton : Pauldrons of the Vanquished Hero
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
