local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Brenton",
    [ 5] = "Doomhart",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Eragoniz",
    [ 9] = "Hánna",
    [10] = "Jeani",
    [11] = "Jwarrior",
    [12] = "Lamishra",
    [13] = "Malgeth",
    [14] = "Mythria",
    [15] = "Räkpaj",
    [16] = "Palypoes",
    [17] = "Saray",
    [18] = "Senzubean",
    [19] = "Tidanbo",
    [20] = "Volrik",
    [21] = "Vrilya",
    [22] = "Locktorius",
    [23] = "Zabishii",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-13 19:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23}},
    {boss = 649, timestamp = "2022-01-13 19:13", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23}},
    {boss = 650, timestamp = "2022-01-13 19:26", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23}},
    {boss = 651, timestamp = "2022-01-13 19:47", players = {1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23}},
    {boss = 901, timestamp = "2022-01-13 20:00", players = {1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
