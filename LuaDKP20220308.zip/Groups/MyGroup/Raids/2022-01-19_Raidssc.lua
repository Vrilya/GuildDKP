local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bizkup",
    [ 4] = "Breadshadow",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Gavun",
    [ 9] = "Hánna",
    [10] = "Jeani",
    [11] = "Jwarrior",
    [12] = "Knockmeup",
    [13] = "Ksiadzropak",
    [14] = "Lamishra",
    [16] = "Locktorius",
    [17] = "Malgeth",
    [19] = "Mythria",
    [20] = "Palypoes",
    [21] = "Rhagnor",
    [22] = "Saray",
    [23] = "Shushi",
    [24] = "Sint",
    [25] = "Tidanbo",
    [26] = "Volrik",
    [27] = "Vrilya",
    [28] = "Ælizabeth",
    [18] = "Doomhart",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-19 19:01", players = {1,2,4,5,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 623, timestamp = "2022-01-19 19:18", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 624, timestamp = "2022-01-19 19:28", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 628, timestamp = "2022-01-19 19:55", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 625, timestamp = "2022-01-19 20:24", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 626, timestamp = "2022-01-19 20:42", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 627, timestamp = "2022-01-19 21:22", players = {1,2,4,5,6,7,8,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 649, timestamp = "2022-01-19 21:50", players = {1,2,4,5,6,7,8,10,11,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 650, timestamp = "2022-01-19 22:02", players = {1,2,4,5,6,7,8,10,11,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
    {boss = 901, timestamp = "2022-01-19 22:03", players = {1,2,4,5,6,7,8,10,11,13,14,16,17,19,20,21,22,23,24,25,26,27,28}},
  },
  drops = {
    {player =  2, timestamp = "2022-01-19 19:30", item = 30067}, -- Bagts : Velvet Boots of the Guardian
    {player = 24, timestamp = "2022-01-19 19:57", item = 30243}, -- Sint : Helm of the Vanquished Defender
    {player = 23, timestamp = "2022-01-19 19:58", item = 30243}, -- Shushi : Helm of the Vanquished Defender
    {player =  7, timestamp = "2022-01-19 19:58", item = 30243}, -- Fauxxy : Helm of the Vanquished Defender
    {player = 17, timestamp = "2022-01-19 19:59", item = 30107}, -- Malgeth : Vestments of the Sea-Witch
    {player =  9, timestamp = "2022-01-19 20:26", item = 30239}, -- Hánna : Gloves of the Vanquished Champion
    {player = 25, timestamp = "2022-01-19 20:27", item = 30627}, -- Tidanbo : Tsunami Talisman
    {player = 21, timestamp = "2022-01-19 20:43", item = 30247}, -- Rhagnor : Leggings of the Vanquished Hero
    {player =  4, timestamp = "2022-01-19 20:44", item = 30246}, -- Breadshadow : Leggings of the Vanquished Defender
    {player = 11, timestamp = "2022-01-19 20:44", item = 30246}, -- Jwarrior : Leggings of the Vanquished Defender
    {player = 16, timestamp = "2022-01-19 20:45", item = 30626}, -- Locktorius : Sextant of Unstable Currents
    {player =  6, timestamp = "2022-01-19 21:24", item = 30081}, -- Ejectoseato : Warboots of Obliteration
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
