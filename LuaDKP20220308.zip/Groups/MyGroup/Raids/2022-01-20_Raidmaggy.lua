local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Palba",
    [ 2] = "Animelove",
    [ 3] = "Bagts",
    [ 4] = "Breadshadow",
    [ 5] = "Bággen",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Fauxxy",
    [ 9] = "Galactûs",
    [10] = "Husqie",
    [11] = "Jeani",
    [12] = "Kialya",
    [13] = "Lamishra",
    [14] = "Malgeth",
    [15] = "Räkpaj",
    [16] = "Palypoes",
    [17] = "Saray",
    [18] = "Tidanbo",
    [19] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-20 19:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19}},
    {boss = 651, timestamp = "2022-01-20 19:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19}},
    {boss = 901, timestamp = "2022-01-20 19:37", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
