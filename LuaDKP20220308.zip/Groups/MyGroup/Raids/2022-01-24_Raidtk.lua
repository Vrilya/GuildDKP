local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Fauxxy",
    [ 7] = "Husqie",
    [ 8] = "Hánna",
    [ 9] = "Jeani",
    [10] = "Jwarrior",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Locktorius",
    [14] = "Malgeth",
    [15] = "Mythria",
    [16] = "Räkpaj",
    [17] = "Palypoes",
    [18] = "Rhagnor",
    [19] = "Saray",
    [20] = "Shushi",
    [21] = "Sint",
    [22] = "Tidanbo",
    [23] = "Volrik",
    [24] = "Vrilya",
    [25] = "Ælizabeth",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-24 18:55", players = {1,2,3,4,5,6,7,8,9,10,12,13,14,15,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2022-01-24 19:24", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2022-01-24 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2022-01-24 20:19", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 733, timestamp = "2022-01-24 20:56", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-01-24 20:57", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 16, timestamp = "2022-01-24 20:02", item = 30250}, -- Onionring : Pauldrons of the Vanquished Hero
    {player =  8, timestamp = "2022-01-24 20:02", item = 30248}, -- Hánna : Pauldrons of the Vanquished Champion
    {player = 21, timestamp = "2022-01-24 20:20", item = 29972}, -- Sint : Trousers of the Astromancer
    {player = 18, timestamp = "2022-01-24 20:21", item = 29966}, -- Rhagnor : Vambraces of Ending
    {player = 14, timestamp = "2022-01-24 20:58", item = 32405}, -- Malgeth : Verdant Sphere
    {player = 11, timestamp = "2022-01-24 20:59", item = 29989}, -- Ksiadzropak : Sunshower Light Cloak
    {player =  7, timestamp = "2022-01-24 21:00", item = 29994}, -- Husqie : Thalassian Wildercloak
    {player = 20, timestamp = "2022-01-24 21:01", item = 30237}, -- Shushi : Chestguard of the Vanquished Defender
    {player = 12, timestamp = "2022-01-24 21:01", item = 30236}, -- Lamishra : Chestguard of the Vanquished Champion
    {player =  8, timestamp = "2022-01-24 21:02", item = 30236}, -- Hánna : Chestguard of the Vanquished Champion
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
