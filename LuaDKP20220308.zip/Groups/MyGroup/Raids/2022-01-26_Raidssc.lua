local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Eragoniz",
    [ 8] = "Fauxxy",
    [ 9] = "Husqie",
    [10] = "Jeani",
    [11] = "Jwarrior",
    [12] = "Knockmeup",
    [13] = "Ksiadzropak",
    [14] = "Lamishra",
    [15] = "Locktorius",
    [16] = "Malgeth",
    [17] = "Mythria",
    [18] = "Palypoes",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Sint",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-26 19:04", players = {1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,24,25}},
    {boss = 623, timestamp = "2022-01-26 19:20", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2022-01-26 19:34", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 628, timestamp = "2022-01-26 19:49", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2022-01-26 20:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2022-01-26 20:25", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 627, timestamp = "2022-01-26 20:38", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 730, timestamp = "2022-01-26 21:11", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 731, timestamp = "2022-01-26 21:33", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 733, timestamp = "2022-01-26 21:59", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 732, timestamp = "2022-01-26 22:18", players = {1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-01-26 22:19", players = {1,2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 10, timestamp = "2022-01-26 19:22", item = 32516}, -- Jeani : Wraps of Purification
    {player = 18, timestamp = "2022-01-26 19:27", item = 30055}, -- Palypoes : Shoulderpads of the Stranger
    {player = 14, timestamp = "2022-01-26 20:46", item = 30242}, -- Lamishra : Helm of the Vanquished Champion
    {player =  7, timestamp = "2022-01-26 20:47", item = 30242}, -- Eragoniz : Helm of the Vanquished Champion
    {player =  7, timestamp = "2022-01-26 20:48", item = 30052}, -- Eragoniz : Ring of Lethality
    {player = 21, timestamp = "2022-01-26 20:49", item = 30246}, -- Shushi : Leggings of the Vanquished Defender
    {player =  9, timestamp = "2022-01-26 20:50", item = 30247}, -- Husqie : Leggings of the Vanquished Hero
    {player = 20, timestamp = "2022-01-26 20:50", item = 30247}, -- Saray : Leggings of the Vanquished Hero
    {player = 10, timestamp = "2022-01-26 20:52", item = 30240}, -- Jeani : Gloves of the Vanquished Defender
    {player = 10, timestamp = "2022-01-26 20:57", item = 30100}, -- Jeani : Soul-Strider Boots
    {player = 22, timestamp = "2022-01-26 20:57", item = 30109}, -- Sint : Ring of Endless Coils
    {player = 23, timestamp = "2022-01-26 21:03", item = 30102}, -- Tidanbo : Krakken-Heart Breastplate
    {player = 17, timestamp = "2022-01-26 22:01", item = 32405}, -- Mythria : Verdant Sphere
    {player =  7, timestamp = "2022-01-26 22:02", item = 29996}, -- Eragoniz : Rod of the Sun King
    {player =  5, timestamp = "2022-01-26 22:03", item = 29989}, -- Eclipce : Sunshower Light Cloak
    {player =  7, timestamp = "2022-01-26 22:04", item = 30236}, -- Eragoniz : Chestguard of the Vanquished Champion
    {player =  8, timestamp = "2022-01-26 22:06", item = 29918}, -- Fauxxy : Mindstorm Wristbands
    {player =  3, timestamp = "2022-01-26 22:10", item = 29947}, -- Breadshadow : Gloves of the Searing Grip
    {player =  6, timestamp = "2022-01-26 22:13", item = 30249}, -- Ejectoseato : Pauldrons of the Vanquished Defender
    {player = 16, timestamp = "2022-01-26 22:19", item = 29982}, -- Malgeth : Wand of the Forgotten Star
    {player =  9, timestamp = "2022-01-26 22:19", item = 29951}, -- Husqie : Star-Strider Boots
    {player = 16, timestamp = "2022-01-26 22:20", item = 30449}, -- Malgeth : Void Star Talisman
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
