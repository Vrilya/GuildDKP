local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Palba",
    [ 2] = "Animelove",
    [ 3] = "Breadshadow",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Eragoniz",
    [ 7] = "Fauxxy",
    [ 8] = "Knockmeup",
    [ 9] = "Husqie",
    [10] = "Jeani",
    [11] = "Lamishra",
    [12] = "Maclourion",
    [13] = "Malgeth",
    [14] = "Misandri",
    [15] = "Mythria",
    [16] = "Räkpaj",
    [17] = "Palypoes",
    [18] = "Saray",
    [19] = "Sint",
    [20] = "Spoinky",
    [21] = "Tidanbo",
    [22] = "Volrik",
    [23] = "Vrilya",
    [24] = "Zabishii",
  },
  kills = {
    {boss = 900, timestamp = "2022-01-27 20:06", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,16,17,18,19,20,21,22,23}},
    {boss = 649, timestamp = "2022-01-27 20:11", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,16,17,18,19,20,21,22,23}},
    {boss = 650, timestamp = "2022-01-27 20:24", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,16,17,18,19,20,21,22,23}},
    {boss = 651, timestamp = "2022-01-27 21:16", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,23,24}},
    {boss = 901, timestamp = "2022-01-27 21:17", players = {1,2,3,4,5,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,23,24}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
