local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Hánna",
    [ 9] = "Jeani",
    [10] = "Jwarrior",
    [11] = "Knockmeup",
    [12] = "Ksiadzropak",
    [13] = "Lamishra",
    [14] = "Locktorius",
    [15] = "Malgeth",
    [16] = "Mythria",
    [17] = "Räkpaj",
    [18] = "Palypoes",
    [19] = "Rhagnor",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Sint",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-01-31 18:57", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 618, timestamp = "2022-01-31 19:32", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
        {boss = 906, timestamp = "2022-01-31 19:33", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 619, timestamp = "2022-01-31 20:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
        {boss = 906, timestamp = "2022-01-31 20:36", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 620, timestamp = "2022-01-31 22:03", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
        {boss = 906, timestamp = "2022-01-31 22:04", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-01-31 22:09", players = {1,2,3,4,5,6,7,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player =  8, timestamp = "2022-01-31 19:35", item = 30873}, -- Hánna : Stillwater Boots
    {player = 22, timestamp = "2022-01-31 19:37", item = 32590}, -- Sint : Nethervoid Cloak
    {player = 17, timestamp = "2022-01-31 20:46", item = 30884}, -- Onionring : Hatefury Mantle
    {player = 16, timestamp = "2022-01-31 20:47", item = 30879}, -- Mythria : Don Alejandro's Money Belt
    {player = 13, timestamp = "2022-01-31 20:47", item = 32592}, -- Lamishra : Chestguard of Relentless Storms
    {player = 15, timestamp = "2022-01-31 20:48", item = 32590}, -- Malgeth : Nethervoid Cloak
    {player = 14, timestamp = "2022-01-31 21:22", item = 32590}, -- Locktorius : Nethervoid Cloak
    {player =  6, timestamp = "2022-01-31 21:23", item = 32591}, -- Ejectoseato : Choker of Serrated Blades
    {player =  1, timestamp = "2022-01-31 22:07", item = 30889}, -- Animelove : Kaz'rogal's Hardened Heart
    {player = 23, timestamp = "2022-01-31 22:10", item = 32591}, -- Tidanbo : Choker of Serrated Blades
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
