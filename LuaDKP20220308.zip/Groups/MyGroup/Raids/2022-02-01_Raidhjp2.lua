local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Coxie",
    [ 5] = "Dragònhunter",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Fauxxy",
    [ 9] = "Jwarrior",
    [10] = "Knockmeup",
    [11] = "Lamishra",
    [12] = "Locktorius",
    [13] = "Madhaus",
    [14] = "Malgeth",
    [15] = "Mythria",
    [16] = "Räkpaj",
    [17] = "Palypoes",
    [18] = "Rhagnor",
    [19] = "Saray",
    [20] = "Shushi",
    [21] = "Sint",
    [22] = "Tidanbo",
    [23] = "Volrik",
    [24] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-01 19:03", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 907, timestamp = "2022-02-01 20:30", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 905, timestamp = "2022-02-01 22:01", players = {1,2,3,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
  },
  drops = {
    {player = 18, timestamp = "2022-02-01 22:02", item = 32946}, -- Rhagnor : Claw of Molten Fury
    {player = 18, timestamp = "2022-02-01 22:03", item = 32945}, -- Rhagnor : Fist of Molten Fury
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
