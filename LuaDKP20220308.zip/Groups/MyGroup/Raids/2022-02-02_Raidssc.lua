local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Fauxxy",
    [ 7] = "Husqie",
    [ 8] = "Hánna",
    [ 9] = "Jeani",
    [10] = "Jwarrior",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Locktorius",
    [14] = "Maclourion",
    [15] = "Malgeth",
    [16] = "Mygrain",
    [17] = "Mythria",
    [18] = "Palypoes",
    [19] = "Rhagnor",
    [20] = "Räkpaj",
    [21] = "Saray",
    [22] = "Sint",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
    [26] = "Zabishii",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-02 18:58", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,23,24,25,26}},
    {boss = 623, timestamp = "2022-02-02 19:13", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26}},
    {boss = 624, timestamp = "2022-02-02 19:23", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26}},
    {boss = 628, timestamp = "2022-02-02 19:41", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26}},
    {boss = 625, timestamp = "2022-02-02 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25,26}},
    {boss = 626, timestamp = "2022-02-02 20:21", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 627, timestamp = "2022-02-02 20:38", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 730, timestamp = "2022-02-02 21:25", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 731, timestamp = "2022-02-02 21:45", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 733, timestamp = "2022-02-02 22:11", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 732, timestamp = "2022-02-02 22:32", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 901, timestamp = "2022-02-02 22:33", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
  },
  drops = {
    {player = 22, timestamp = "2022-02-02 20:31", item = 30050}, -- Sint : Boots of the Shifting Nightmare
    {player = 20, timestamp = "2022-02-02 20:32", item = 30047}, -- Räkpaj : Blackfathom Warbands
    {player = 20, timestamp = "2022-02-02 20:48", item = 30066}, -- Räkpaj : Tempest-Strider Boots
    {player =  8, timestamp = "2022-02-02 20:49", item = 30063}, -- Hánna : Libram of Absolute Truth
    {player = 16, timestamp = "2022-02-02 20:51", item = 30104}, -- Mygrain : Cobra-Lash Boots
    {player = 25, timestamp = "2022-02-02 20:52", item = 30243}, -- Vrilya : Helm of the Vanquished Defender
    {player =  3, timestamp = "2022-02-02 20:53", item = 30243}, -- Breadshadow : Helm of the Vanquished Defender
    {player =  4, timestamp = "2022-02-02 20:53", item = 30243}, -- Eclipce : Helm of the Vanquished Defender
--    {player = 20, timestamp = "2022-02-02 20:54", item = 30097}, -- Räkpaj : Coral-Barbed Shoulderpads
    {player =  4, timestamp = "2022-02-02 20:55", item = 30240}, -- Eclipce : Gloves of the Vanquished Defender
    {player =  3, timestamp = "2022-02-02 20:55", item = 30240}, -- Breadshadow : Gloves of the Vanquished Defender
    {player = 23, timestamp = "2022-02-02 20:55", item = 30240}, -- Tidanbo : Gloves of the Vanquished Defender
    {player = 26, timestamp = "2022-02-02 20:59", item = 30245}, -- Zabishii : Leggings of the Vanquished Champion
    {player =  4, timestamp = "2022-02-02 20:59", item = 30246}, -- Eclipce : Leggings of the Vanquished Defender
    {player = 23, timestamp = "2022-02-02 21:00", item = 30246}, -- Tidanbo : Leggings of the Vanquished Defender
--    {player = 20, timestamp = "2022-02-02 21:02", item = 30075}, -- Räkpaj : Gnarled Chestpiece of the Ancients
    {player = 16, timestamp = "2022-02-02 21:26", item = 29949}, -- Mygrain : Arcanite Steam-Pistol
    {player =  6, timestamp = "2022-02-02 22:12", item = 32405}, -- Fauxxy : Verdant Sphere
    {player = 14, timestamp = "2022-02-02 22:13", item = 29987}, -- Maclourion : Gauntlets of the Sun King
    {player =  7, timestamp = "2022-02-02 22:14", item = 29995}, -- Husqie : Leggings of Murderous Intent
    {player =  5, timestamp = "2022-02-02 22:14", item = 30237}, -- Ejectoseato : Chestguard of the Vanquished Defender
    {player = 20, timestamp = "2022-02-02 22:15", item = 30236}, -- Räkpaj : Chestguard of the Vanquished Champion
    {player = 26, timestamp = "2022-02-02 22:17", item = 30236}, -- Zabishii : Chestguard of the Vanquished Champion
    {player = 14, timestamp = "2022-02-02 22:22", item = 30250}, -- Maclourion : Pauldrons of the Vanquished Hero
    {player = 10, timestamp = "2022-02-02 22:23", item = 30249}, -- Jwarrior : Pauldrons of the Vanquished Defender
    {player = 20, timestamp = "2022-02-02 22:25", item = 30248}, -- Räkpaj : Pauldrons of the Vanquished Champion
    {player = 26, timestamp = "2022-02-02 22:26", item = 30030}, -- Zabishii : Girdle of Fallen Stars
    {player =  1, timestamp = "2022-02-02 22:27", item = 30447}, -- Animelove : Tome of Fiery Redemption
    {player = 20, timestamp = "2022-02-02 22:33", item = 30029}, -- Räkpaj : Bark-Gloves of Ancient Wisdom
    {player = 20, timestamp = "2022-02-02 22:33", item = 29977}, -- Räkpaj : Star-Soul Breeches
    {player =  8, timestamp = "2022-02-02 22:34", item = 29965}, -- Hánna : Girdle of the Righteous Path
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
