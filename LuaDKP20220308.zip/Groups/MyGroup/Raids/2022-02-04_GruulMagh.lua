local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Bagts",
    [ 2] = "Ksiadzropak",
    [ 3] = "Bággen",
    [ 4] = "Doomhart",
    [ 5] = "Fauxxy",
    [ 6] = "Knockmeup",
    [ 7] = "Husqie",
    [ 8] = "Hánna",
    [ 9] = "Jeani",
    [10] = "Lamishra",
    [11] = "Maclourion",
    [12] = "Misandri",
    [13] = "Mygrain",
    [14] = "Palba",
    [15] = "Rhagnor",
    [16] = "Räkpaj",
    [17] = "Saray",
    [18] = "Shocktherapy",
    [19] = "Sint",
    [20] = "Poppetje",
    [21] = "Tidanbo",
    [22] = "Vrilya",
    [23] = "Locktorius",
    [24] = "Zabishii",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-04 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 649, timestamp = "2022-02-04 20:20", players = {1,2,3,4,5,6,7,8,9,10,11,12,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 650, timestamp = "2022-02-04 20:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 651, timestamp = "2022-02-04 21:25", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24}},
    {boss = 901, timestamp = "2022-02-04 21:26", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,24}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
