local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bobiko",
    [ 4] = "Breadshadow",
    [ 5] = "Doomhart",
    [ 6] = "Dragònhunter",
    [ 7] = "Eclipce",
    [ 8] = "Ejectoseato",
    [ 9] = "Fauxxy",
    [10] = "Husqie",
    [11] = "Hánna",
    [12] = "Jeani",
    [13] = "Jwarrior",
    [14] = "Ksiadzropak",
    [15] = "Lamishra",
    [16] = "Locktorius",
    [17] = "Maclourion",
    [18] = "Malgeth",
    [19] = "Mythria",
    [20] = "Palypoes",
    [21] = "Shushi",
    [22] = "Sint",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-07 18:59", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 618, timestamp = "2022-02-07 19:16", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 619, timestamp = "2022-02-07 19:33", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 620, timestamp = "2022-02-07 20:02", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 621, timestamp = "2022-02-07 21:25", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-07 21:26", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-07 22:01", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 11, timestamp = "2022-02-07 19:19", item = 30869}, -- Hánna : Howling Wind Bracers
    {player = 19, timestamp = "2022-02-07 19:20", item = 32591}, -- Mythria : Choker of Serrated Blades
    {player = 23, timestamp = "2022-02-07 19:34", item = 30874}, -- Tidanbo : The Unbreakable Will
    {player =  4, timestamp = "2022-02-07 19:34", item = 30883}, -- Breadshadow : Pillar of Ferocity
    {player =  4, timestamp = "2022-02-07 21:26", item = 31093}, -- Breadshadow : Gloves of the Forgotten Vanquisher
    {player = 13, timestamp = "2022-02-07 21:28", item = 31094}, -- Jwarrior : Gloves of the Forgotten Protector
    {player =  6, timestamp = "2022-02-07 21:28", item = 30900}, -- Dragonhunter : Bow-stitched Leggings
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
