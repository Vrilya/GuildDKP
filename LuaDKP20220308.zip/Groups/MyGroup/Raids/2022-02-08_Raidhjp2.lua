local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Dragònhunter",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Fauxxy",
    [ 9] = "Husqie",
    [10] = "Hánna",
    [11] = "Jeani",
    [12] = "Jwarrior",
    [13] = "Lamishra",
    [14] = "Locktorius",
    [15] = "Maclourion",
    [16] = "Malgeth",
    [17] = "Mythria",
    [18] = "Palypoes",
    [19] = "Räkpaj",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Sint",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-08 18:56", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 622, timestamp = "2022-02-08 21:13", players = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-08 21:14", players = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-08 21:15", players = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player =  8, timestamp = "2022-02-08 21:14", item = 31096}, -- Fauxxy : Helm of the Forgotten Vanquisher
    {player =  3, timestamp = "2022-02-08 21:15", item = 31096}, -- Breadshadow : Helm of the Forgotten Vanquisher
    {player =  6, timestamp = "2022-02-08 21:16", item = 30908}, -- Eclipce : Apostle of Argus
    {player = 17, timestamp = "2022-02-08 21:17", item = 30907}, -- Mythria : Mail of Fevered Pursuit
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
