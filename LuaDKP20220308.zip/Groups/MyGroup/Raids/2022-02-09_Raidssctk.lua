local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Doomhart",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Knockmeup",
    [ 9] = "Husqie",
    [10] = "Jwarrior",
    [11] = "Ksiadzropak",
    [12] = "Lamishra",
    [13] = "Locktorius",
    [14] = "Maclourion",
    [15] = "Malgeth",
    [16] = "Misandri",
    [17] = "Mygrain",
    [18] = "Mythria",
    [19] = "Palypoes",
    [20] = "Paynz",
    [21] = "Räkpaj",
    [22] = "Saray",
    [23] = "Shushi",
    [24] = "Tidanbo",
    [25] = "Volrik",
    [26] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-09 18:54", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 624, timestamp = "2022-02-09 19:27", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 628, timestamp = "2022-02-09 19:46", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 625, timestamp = "2022-02-09 20:11", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 626, timestamp = "2022-02-09 20:33", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 627, timestamp = "2022-02-09 20:50", players = {1,2,3,4,5,6,7,8,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 730, timestamp = "2022-02-09 21:28", players = {1,2,3,4,5,6,7,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 733, timestamp = "2022-02-09 22:00", players = {1,2,3,4,5,6,7,9,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 901, timestamp = "2022-02-09 22:07", players = {1,2,3,4,5,6,9,11,12,14,15,16,17,18,20,21,22,23,24,26}},
  },
  drops = {
    {player = 14, timestamp = "2022-02-09 19:13", item = 30056}, -- Maclourion : Robe of Hateful Echoes
    {player =  4, timestamp = "2022-02-09 19:48", item = 30110}, -- Doomhart : Coral Band of the Revived
    {player = 11, timestamp = "2022-02-09 19:50", item = 30243}, -- Ksiadzropak : Helm of the Vanquished Defender
    {player = 21, timestamp = "2022-02-09 19:51", item = 30242}, -- Räkpaj : Helm of the Vanquished Champion
    {player = 18, timestamp = "2022-02-09 19:52", item = 30244}, -- Mythria : Helm of the Vanquished Hero
    {player = 21, timestamp = "2022-02-09 20:14", item = 30239}, -- Räkpaj : Gloves of the Vanquished Champion
    {player = 23, timestamp = "2022-02-09 20:15", item = 30240}, -- Shushi : Gloves of the Vanquished Defender
    {player = 14, timestamp = "2022-02-09 20:16", item = 30241}, -- Maclourion : Gloves of the Vanquished Hero
    {player = 21, timestamp = "2022-02-09 20:36", item = 30245}, -- Räkpaj : Leggings of the Vanquished Champion
    {player = 16, timestamp = "2022-02-09 20:37", item = 30246}, -- Misandri : Leggings of the Vanquished Defender
    {player = 14, timestamp = "2022-02-09 20:39", item = 30247}, -- Maclourion : Leggings of the Vanquished Hero
    {player =  4, timestamp = "2022-02-09 21:04", item = 33058}, -- Doomhart : Band of the Vigilant
    {player = 21, timestamp = "2022-02-09 21:29", item = 29920}, -- Räkpaj : Phoenix-Ring of Rebirth
    {player = 22, timestamp = "2022-02-09 22:02", item = 30238}, -- Saray : Chestguard of the Vanquished Hero
    {player = 18, timestamp = "2022-02-09 22:02", item = 30238}, -- Mythria : Chestguard of the Vanquished Hero
    {player = 11, timestamp = "2022-02-09 22:04", item = 30237}, -- Ksiadzropak : Chestguard of the Vanquished Defender
    {player = 17, timestamp = "2022-02-09 22:05", item = 29994}, -- Mythria : Thalassian Wildercloak
    {player =  1, timestamp = "2022-02-09 22:06", item = 32405}, -- Animelove : Verdant Sphere
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
