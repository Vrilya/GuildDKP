local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
	[ 1] = "Animelove",
	[ 2] = "Woolypally",
	[ 3] = "Vrilya",
	[ 4] = "Zabishii",
	[ 5] = "Mygrain",
	[ 6] = "Xanu",
	[ 7] = "Bagts",
	[ 8] = "Maclourion",
	[ 9] = "Saray",
	[10] = "Palypoes",
	[11] = "Hauganzki",
	[12] = "Lamishra",
	[13] = "Grimassi",
	[14] = "Ràgè",
	[15] = "Terrorciccio",
	[16] = "Tidanbo",
	[17] = "Misandri",
	[18] = "Eclipce",
	[19] = "Shushi",
	[20] = "Wigzz",
	[21] = "Räkpaj",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-11 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21}},
    {boss = 649, timestamp = "2022-02-11 20:20", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21}},
    {boss = 650, timestamp = "2022-02-11 20:45", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21}},
    {boss = 901, timestamp = "2022-02-11 20:50", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
