local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Fauxxy",
    [ 7] = "Jeani",
    [ 8] = "Jwarrior",
    [ 9] = "Knockmeup",
    [10] = "Lamishra",
    [11] = "Locktorius",
    [12] = "Maclourion",
    [13] = "Malgeth",
    [14] = "Misandri",
    [15] = "Ninakraviz",
    [16] = "Palypoes",
    [17] = "Paynz",
    [18] = "Räkpaj",
    [19] = "Saray",
    [20] = "Stolnikova",
    [21] = "Tidanbo",
    [22] = "Volrik",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Zofija",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-14 18:59", players = {1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 618, timestamp = "2022-02-14 19:20", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 619, timestamp = "2022-02-14 19:38", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 620, timestamp = "2022-02-14 20:29", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 621, timestamp = "2022-02-14 20:57", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 622, timestamp = "2022-02-14 22:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-14 22:15", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 17, timestamp = "2022-02-14 19:24", item = 30862}, -- Paynz : Blessed Adamantite Bracers
    {player =  7, timestamp = "2022-02-14 19:39", item = 32609}, -- Jeani : Boots of the Divine Light
    {player =  6, timestamp = "2022-02-14 19:40", item = 34009}, -- Fauxxy : Hammer of Judgement
    {player = 17, timestamp = "2022-02-14 19:41", item = 30878}, -- Paynz : Glimmering Steel Mantle
    {player = 14, timestamp = "2022-02-14 19:43", item = 30885}, -- Misandri : Archbishop's Slippers
    {player =  4, timestamp = "2022-02-14 20:59", item = 32609}, -- Eclipce : Boots of the Divine Light
    {player = 18, timestamp = "2022-02-14 21:03", item = 32609}, -- Räkpaj : Boots of the Divine Light
    {player =  9, timestamp = "2022-02-14 21:04", item = 32609}, -- Knockmeup : Boots of the Divine Light
    {player = 24, timestamp = "2022-02-14 21:06", item = 30893}, -- Zabishii : Sun-touched Chain Leggings
    {player = 22, timestamp = "2022-02-14 21:07", item = 30916}, -- Volrik : Leggings of Channeled Elements
    {player = 10, timestamp = "2022-02-14 21:35", item = 31094}, -- Lamishra : Gloves of the Forgotten Protector
    {player =  1, timestamp = "2022-02-14 22:07", item = 31092}, -- Animelove : Gloves of the Forgotten Conqueror
    {player =  9, timestamp = "2022-02-14 22:10", item = 31096}, -- Knockmeup : Helm of the Forgotten Vanquisher
    {player = 23, timestamp = "2022-02-14 22:11", item = 31095}, -- Vrilya : Helm of the Forgotten Protector
    {player =  7, timestamp = "2022-02-14 22:13", item = 30912}, -- Jeani : Leggings of Eternity
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
