local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bishye",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Fauxxy",
    [ 7] = "Graier",
    [ 8] = "Jwarrior",
    [ 9] = "Lamishra",
    [10] = "Locktorius",
    [11] = "Maclourion",
    [12] = "Malgeth",
    [13] = "Misandri",
    [14] = "Moccasin",
    [15] = "Palypoes",
    [16] = "Paynz",
    [17] = "Räkpaj",
    [18] = "Shushi",
    [19] = "Sint",
    [20] = "Stolnikova",
    [21] = "Tidanbo",
    [22] = "Volrik",
    [23] = "Vrilya",
    [24] = "Zabishii",
    [25] = "Zofija",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-15 19:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 601, timestamp = "2022-02-15 19:48", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-15 19:49", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 602, timestamp = "2022-02-15 20:27", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-15 20:28", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 603, timestamp = "2022-02-15 21:08", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-15 21:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 604, timestamp = "2022-02-15 21:50", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-15 21:51", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-15 21:55", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 20, timestamp = "2022-02-15 19:49", item = 32234}, -- Stolnikova : Fists of Mukoa
    {player = 10, timestamp = "2022-02-15 19:51", item = 32247}, -- Locktorius : Ring of Captured Storms
    {player = 23, timestamp = "2022-02-15 20:28", item = 32253}, -- Vrilya : Legionkiller
    {player = 19, timestamp = "2022-02-15 20:30", item = 32256}, -- Sint : Waistwrap of Infinity
    {player =  9, timestamp = "2022-02-15 21:10", item = 32276}, -- Lamishra : Flashfire Girdle
    {player = 15, timestamp = "2022-02-15 21:52", item = 32323}, -- Palypoes : Shadowmoon Destroyer's Drape
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
