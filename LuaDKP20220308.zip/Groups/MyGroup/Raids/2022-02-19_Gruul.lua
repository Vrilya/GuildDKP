local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Abelinc",
    [ 2] = "Astorah",
    [ 3] = "Ballentine",
    [ 4] = "Breadshadow",
    [ 5] = "Dotandrot",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Gudstad",
    [ 9] = "Humawarr",
    [10] = "Jaini",
    [11] = "Lamishra",
    [12] = "Loiuz",
    [13] = "Maclourion",
    [14] = "Misandri",
    [15] = "Mygrain",
    [16] = "Obamna",
    [17] = "Palypoes",
    [18] = "Rissie",
    [19] = "Räkpaj",
    [20] = "Saray",
    [21] = "Shelobb",
    [22] = "Shushi",
    [23] = "Tidanbo",
    [24] = "Valaeryon",
    [25] = "Vims",
    [26] = "Vrilya",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-19 20:04", players = {1,2,3,4,5,6,7,8,9,11,13,14,15,16,17,19,20,22,23,24,25,26}},
    {boss = 649, timestamp = "2022-02-19 20:28", players = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 650, timestamp = "2022-02-19 20:39", players = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
    {boss = 901, timestamp = "2022-02-19 20:40", players = {1,2,3,4,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
