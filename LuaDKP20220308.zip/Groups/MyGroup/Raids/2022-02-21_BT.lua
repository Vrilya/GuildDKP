local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Fauxxy",
    [ 7] = "Husqie",
    [ 8] = "Jeani",
    [ 9] = "Jwarrior",
    [10] = "Lamishra",
    [11] = "Locktorius",
    [12] = "Maclourion",
    [13] = "Malgeth",
    [14] = "Misandri",
    [15] = "Mygrain",
    [16] = "Mythria",
    [17] = "Palypoes",
    [18] = "Paynz",
    [19] = "Räkpaj",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Sint",
    [23] = "Stolnikova",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-21 20:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 601, timestamp = "2022-02-21 20:17", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 602, timestamp = "2022-02-21 20:35", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 603, timestamp = "2022-02-21 21:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 604, timestamp = "2022-02-21 21:36", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 605, timestamp = "2022-02-21 22:40", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-21 22:41", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 606, timestamp = "2022-02-21 23:03", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-02-21 23:04", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-21 23:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 18, timestamp = "2022-02-21 20:19", item = 32243}, -- Paynz : Pearl Inlaid Boots
    {player = 17, timestamp = "2022-02-21 20:20", item = 32526}, -- Palypoes : Band of Devastation
    {player = 23, timestamp = "2022-02-21 20:38", item = 32262}, -- Stolnikova : Syphon of the Nathrezim
--    {player = 17, timestamp = "2022-02-21 21:39", item = 32348}, -- Palypoes : Soul Cleaver
    {player =  7, timestamp = "2022-02-21 21:39", item = 32324}, -- Husqie : Insidious Bands
    {player = 25, timestamp = "2022-02-21 21:40", item = 32263}, -- Vrilya : Praetorian's Legguards
    {player =  5, timestamp = "2022-02-21 21:41", item = 32278}, -- Ejectoseato : Grips of Silent Justice
    {player = 23, timestamp = "2022-02-21 23:07", item = 32517}, -- Stolnikova : The Wavemender's Mantle
    {player = 17, timestamp = "2022-02-21 23:08", item = 32332}, -- Palypoes : Torch of the Damned
    {player = 18, timestamp = "2022-02-21 23:13", item = 32340}, -- Paynz : Garments of Temperance
    {player =  7, timestamp = "2022-02-21 23:15", item = 32334}, -- Husqie : Vest of Mounting Assault
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
