local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Breadshadow",
    [ 4] = "Eclipce",
    [ 5] = "Ejectoseato",
    [ 6] = "Fauxxy",
    [ 7] = "Husqie",
    [ 8] = "Jwarrior",
    [ 9] = "Lamishra",
    [10] = "Locktorius",
    [11] = "Luandra",
    [12] = "Maclourion",
    [13] = "Malgeth",
    [14] = "Misandri",
    [15] = "Mygrain",
    [16] = "Mythria",
    [17] = "Palypoes",
    [18] = "Paynz",
    [19] = "Räkpaj",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Tidanbo",
    [23] = "Volrik",
    [24] = "Vrilya",
    [25] = "Astorah",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-22 19:00", players = {1,2,3,4,5,6,7,8,9,10,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 733, timestamp = "2022-02-22 19:31", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 607, timestamp = "2022-02-22 20:17", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 906, timestamp = "2022-02-22 20:18", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 908, timestamp = "2022-02-22 21:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 905, timestamp = "2022-02-22 22:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
  },
  drops = {
    {player =  2, timestamp = "2022-02-22 19:37", item = 32405}, -- Bagts : Verdant Sphere
    {player = 23, timestamp = "2022-02-22 19:40", item = 30238}, -- Volrik : Chestguard of the Vanquished Hero
    {player = 20, timestamp = "2022-02-22 19:41", item = 30238}, -- Saray : Chestguard of the Vanquished Hero
    {player = 10, timestamp = "2022-02-22 19:42", item = 29987}, -- Locktorius : Gauntlets of the Sun King
    {player = 12, timestamp = "2022-02-22 19:43", item = 30238}, -- Maclourion : Chestguard of the Vanquished Hero
    {player =  2, timestamp = "2022-02-22 19:44", item = 30020}, -- Bagts : Fire-Cord of the Magus
    {player = 18, timestamp = "2022-02-22 20:03", item = 32608}, -- Paynz : Pillager's Gauntlets
    {player = 13, timestamp = "2022-02-22 20:19", item = 31101}, -- Malgeth : Pauldrons of the Forgotten Conqueror
    {player =  1, timestamp = "2022-02-22 20:19", item = 31101}, -- Animelove : Pauldrons of the Forgotten Conqueror
    {player =  1, timestamp = "2022-02-22 20:20", item = 32368}, -- Animelove : Tome of the Lightbringer
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
