local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bobiko",
    [ 4] = "Breadshadow",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Jeani",
    [ 9] = "Jwarrior",
    [10] = "Lamishra",
    [11] = "Locktorius",
    [12] = "Maclourion",
    [13] = "Malgeth",
    [14] = "Misandri",
    [15] = "Mygrain",
    [16] = "Mythria",
    [17] = "Palypoes",
    [18] = "Paynz",
    [19] = "Rhagnor",
    [20] = "Räkpaj",
    [21] = "Saray",
    [22] = "Shushi",
    [23] = "Stolnikova",
    [24] = "Tidanbo",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-23 18:58", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 618, timestamp = "2022-02-23 19:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 619, timestamp = "2022-02-23 19:27", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 620, timestamp = "2022-02-23 19:53", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 621, timestamp = "2022-02-23 20:11", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 622, timestamp = "2022-02-23 20:31", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 601, timestamp = "2022-02-23 21:02", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 602, timestamp = "2022-02-23 21:22", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 603, timestamp = "2022-02-23 22:04", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-23 22:06", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,22,23,24,25}},
  },
  drops = {
    {player = 17, timestamp = "2022-02-23 19:15", item = 30861}, -- Palypoes : Furious Shackles
    {player = 20, timestamp = "2022-02-23 19:16", item = 30869}, -- Räkpaj : Howling Wind Bracers
    {player = 20, timestamp = "2022-02-23 19:29", item = 30882}, -- Räkpaj : Bastion of Light
    {player =  3, timestamp = "2022-02-23 19:32", item = 30886}, -- Bobiko : Enchanted Leather Sandals
--    {player = 17, timestamp = "2022-02-23 19:54", item = 30891}, -- Palypoes : Black Featherlight Boots
    {player = 12, timestamp = "2022-02-23 20:15", item = 30894}, -- Maclourion : Blue Suede Shoes
    {player =  7, timestamp = "2022-02-23 20:16", item = 31093}, -- Fauxxy : Gloves of the Forgotten Vanquisher
    {player = 16, timestamp = "2022-02-23 20:17", item = 31094}, -- Mythria : Gloves of the Forgotten Protector
    {player =  3, timestamp = "2022-02-23 20:41", item = 31096}, -- Bobiko : Helm of the Forgotten Vanquisher
    {player =  9, timestamp = "2022-02-23 20:42", item = 31095}, -- Jwarrior : Helm of the Forgotten Protector
    {player = 14, timestamp = "2022-02-23 20:43", item = 30911}, -- Misandri : Scepter of Purification
    {player = 17, timestamp = "2022-02-23 20:46", item = 30905}, -- Palypoes : Midnight Chestguard
    {player = 15, timestamp = "2022-02-23 22:07", item = 32265}, -- Mygrain : Shadow-walker's Cord
    {player = 24, timestamp = "2022-02-23 22:07", item = 32278}, -- Tidanbo : Grips of Silent Justice
    {player = 25, timestamp = "2022-02-23 22:08", item = 32943}, -- Vrilya : Swiftsteel Bludgeon
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
