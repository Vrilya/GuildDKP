local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Vrilya",
    [ 2] = "Aragones",
    [ 3] = "Astorah",
    [ 4] = "Bagts",
    [ 5] = "Eclipce",
    [ 6] = "Fauxxy",
    [ 7] = "Galactûs",
    [ 8] = "Gvim",
    [ 9] = "Hánna",
    [10] = "Lamishra",
    [11] = "Breadshadow",
    [12] = "Likkle",
    [13] = "Maclourion",
    [14] = "Mataskavens",
    [15] = "Misandri",
    [16] = "Mygrain",
    [17] = "Nighthero",
    [18] = "Palypoes",
    [19] = "Paynz",
    [20] = "Räkpaj",
    [21] = "Saffyr",
    [22] = "Saray",
    [23] = "Sint",
    [24] = "Stygging",
    [25] = "Tidanbo",
    [26] = "Volrik",
    [27] = "Zalsa",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-24 19:10", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,20,21,22,24,25,26,27}},
    {boss = 624, timestamp = "2022-02-24 19:48", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,24,25,26,27}},
    {boss = 628, timestamp = "2022-02-24 20:47", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,24,25,26,27}},
    {boss = 625, timestamp = "2022-02-24 21:24", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,24,25,26,27}},
    {boss = 626, timestamp = "2022-02-24 21:56", players = {1,2,3,4,5,6,8,9,10,11,12,13,15,16,17,18,19,20,21,22,24,25,26,27}},
    {boss = 627, timestamp = "2022-02-24 22:17", players = {1,2,3,4,5,6,8,9,10,11,12,13,15,17,18,19,20,21,22,23,24,25,26,27}},
    {boss = 901, timestamp = "2022-02-24 22:39", players = {1,2,3,4,5,6,8,9,10,11,12,13,15,17,18,19,20,21,22,23,24,25,26,27}},
  },
  drops = {
    {player =  3, timestamp = "2022-02-24 19:29", item = 30047}, -- Astorah : Blackfathom Warbands
    {player =  6, timestamp = "2022-02-24 19:34", item = 30049}, -- Fauxxy : Fathomstone
    {player = 25, timestamp = "2022-02-24 20:57", item = 30243}, -- Tidanbo : Helm of the Vanquished Defender
    {player =  9, timestamp = "2022-02-24 21:00", item = 30242}, -- Hánna : Helm of the Vanquished Champion
    {player = 15, timestamp = "2022-02-24 21:02", item = 30243}, -- Misandri : Helm of the Vanquished Defender
    {player = 15, timestamp = "2022-02-24 21:07", item = 30108}, -- Misandri : Lightfathom Scepter
    {player = 25, timestamp = "2022-02-24 21:29", item = 30240}, -- Tidanbo : Gloves of the Vanquished Defender
    {player = 19, timestamp = "2022-02-24 22:00", item = 30245}, -- Paynz : Leggings of the Vanquished Champion
--    {player =  9, timestamp = "2022-02-24 22:03", item = 30245}, -- Hánna : Leggings of the Vanquished Champion
    {player =  3, timestamp = "2022-02-24 22:04", item = 30245}, -- Astorah : Leggings of the Vanquished Champion
    {player =  4, timestamp = "2022-02-24 22:18", item = 30720}, -- Bagts : Serpent-Coil Braid
    {player = 18, timestamp = "2022-02-24 22:21", item = 30081}, -- Palypoes : Warboots of Obliteration
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
