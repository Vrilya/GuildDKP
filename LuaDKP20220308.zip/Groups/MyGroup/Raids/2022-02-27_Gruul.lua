local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Astorah",
    [ 2] = "Bartimaeus",
    [ 3] = "Bezzul",
    [ 4] = "Breadshadow",
    [ 5] = "Casperikzz",
    [ 6] = "Hánna",
    [ 7] = "Izmailovsky",
    [ 8] = "Locktorius",
    [ 9] = "Lamishra",
    [10] = "Likkle",
    [11] = "Maclourion",
    [12] = "Magegrimm",
    [13] = "Magicworx",
    [14] = "Misandri",
    [15] = "Moondian",
    [16] = "Mygrain",
    [17] = "Nighthero",
    [18] = "Noccostab",
    [19] = "Nusstraa",
    [20] = "Rhagnor",
    [21] = "Smoofinator",
    [22] = "Spacebandito",
    [23] = "Storyteller",
    [24] = "Vrilya",
    [25] = "Ysblok",
  },
  kills = {
    {boss = 900, timestamp = "2022-02-27 20:03", players = {1,2,4,6,7,8,9,10,11,14,16,17,18,19,20,21,23,24}},
    {boss = 649, timestamp = "2022-02-27 20:36", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 650, timestamp = "2022-02-27 20:48", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 651, timestamp = "2022-02-27 21:14", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-02-27 21:15", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
