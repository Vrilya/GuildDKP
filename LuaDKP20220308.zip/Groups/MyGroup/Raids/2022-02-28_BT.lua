local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bitstar",
    [ 4] = "Breadshadow",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Jeani",
    [ 9] = "Jwarrior",
    [10] = "Lamishra",
    [11] = "Locktorius",
    [12] = "Maclourion",
    [13] = "Malgeth",
    [14] = "Misandri",
    [15] = "Mygrain",
    [16] = "Palypoes",
    [17] = "Paynz",
    [18] = "Rhagnor",
    [19] = "Räkpaj",
    [20] = "Saray",
    [21] = "Shushi",
    [22] = "Stolnikova",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-02-28 19:01", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,21,22,23,24,25}},
    {boss = 604, timestamp = "2022-02-28 19:38", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 606, timestamp = "2022-02-28 20:31", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 605, timestamp = "2022-02-28 21:08", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 607, timestamp = "2022-02-28 21:53", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-02-28 21:55", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,23,24,25}},
  },
  drops = {
    {player = 14, timestamp = "2022-02-28 19:40", item = 32328}, -- Misandri : Botanist's Gloves of Growth
    {player = 22, timestamp = "2022-02-28 19:42", item = 32510}, -- Stolnikova : Softstep Boots of Tracking
    {player =  4, timestamp = "2022-02-28 20:08", item = 32593}, -- Breadshadow : Treads of the Den Mother
    {player =  8, timestamp = "2022-02-28 21:10", item = 32344}, -- Jeani : Staff of Immaculate Recovery
    {player = 11, timestamp = "2022-02-28 21:11", item = 32349}, -- Locktorius : Translucent Spellthread Necklace
    {player =  7, timestamp = "2022-02-28 21:12", item = 32352}, -- Fauxxy : Naturewarden's Treads
    {player = 11, timestamp = "2022-02-28 21:56", item = 32367}, -- Locktorius : Leggings of Devastation
    {player =  4, timestamp = "2022-02-28 21:56", item = 31102}, -- Breadshadow : Pauldrons of the Forgotten Vanquisher
    {player = 21, timestamp = "2022-02-28 21:58", item = 31101}, -- Shushi : Pauldrons of the Forgotten Conqueror
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
