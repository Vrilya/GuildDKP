local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Astorah",
    [ 3] = "Bagts",
    [ 4] = "Breadshadow",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Hårig",
    [ 9] = "Jbelle",
    [10] = "Lamishra",
    [11] = "Locktorius",
    [12] = "Lohkkar",
    [13] = "Luandra",
    [14] = "Maclourion",
    [15] = "Malgeth",
    [16] = "Misandri",
    [17] = "Mygrain",
    [18] = "Naage",
    [19] = "Oldator",
    [20] = "Palypoes",
    [21] = "Räkpaj",
    [22] = "Shushi",
    [23] = "Tidanbo",
    [24] = "Viagrah",
    [25] = "Volrik",
    [26] = "Vrilya",
    [27] = "Jwarrior",
  },
  kills = {
    {boss = 900, timestamp = "2022-03-01 19:00", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,25,26,27}},
    {boss = 730, timestamp = "2022-03-01 19:28", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,19,20,21,22,23,24,25,26,27}},
    {boss = 731, timestamp = "2022-03-01 19:54", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,19,20,21,22,23,24,25,26,27}},
    {boss = 732, timestamp = "2022-03-01 20:11", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,19,20,21,22,23,24,25,26,27}},
    {boss = 733, timestamp = "2022-03-01 20:52", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,19,20,21,22,23,24,25,26,27}},
    {boss = 901, timestamp = "2022-03-01 21:51", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,19,20,21,22,23,24,25,26,27}},
  },
  drops = {
    {player =  2, timestamp = "2022-03-01 19:31", item = 29921}, -- Astorah : Fire Crest Breastplate
    {player = 22, timestamp = "2022-03-01 19:33", item = 29920}, -- Shushi : Phoenix-Ring of Rebirth
    {player = 22, timestamp = "2022-03-01 19:56", item = 30619}, -- Shushi : Fel Reaver's Piston
    {player =  2, timestamp = "2022-03-01 19:57", item = 30248}, -- Astorah : Pauldrons of the Vanquished Champion
    {player =  9, timestamp = "2022-03-01 20:14", item = 29951}, -- Jbelle : Star-Strider Boots
    {player = 22, timestamp = "2022-03-01 20:16", item = 29981}, -- Shushi : Ethereum Life-Staff
    {player =  5, timestamp = "2022-03-01 20:55", item = 32405}, -- Eclipce : Verdant Sphere
    {player =  4, timestamp = "2022-03-01 20:56", item = 30237}, -- Breadshadow : Chestguard of the Vanquished Defender
    {player =  5, timestamp = "2022-03-01 20:58", item = 30237}, -- Eclipce : Chestguard of the Vanquished Defender
    {player = 17, timestamp = "2022-03-01 21:00", item = 30238}, -- Mygrain : Chestguard of the Vanquished Hero
    {player = 10, timestamp = "2022-03-01 21:02", item = 29991}, -- Lamishra : Sunhawk Leggings
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
