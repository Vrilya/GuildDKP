local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bitstar",
    [ 4] = "Bobiko",
    [ 5] = "Breadshadow",
    [ 6] = "Eclipce",
    [ 7] = "Ejectoseato",
    [ 8] = "Gulow",
    [ 9] = "Jeani",
    [10] = "Jwarrior",
    [11] = "Lamishra",
    [12] = "Locktorius",
    [13] = "Luandra",
    [14] = "Maclourion",
    [15] = "Malgeth",
    [16] = "Misandri",
    [17] = "Mygrain",
    [18] = "Palypoes",
    [19] = "Räkpaj",
    [20] = "Shushi",
    [21] = "Stolnikova",
    [22] = "Tidanbo",
    [23] = "Volrik",
    [24] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-03-02 19:12", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 601, timestamp = "2022-03-02 19:24", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 602, timestamp = "2022-03-02 19:46", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 603, timestamp = "2022-03-02 20:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 604, timestamp = "2022-03-02 21:01", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 606, timestamp = "2022-03-02 21:28", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
    {boss = 905, timestamp = "2022-03-02 22:05", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24}},
  },
  drops = {
    {player = 20, timestamp = "2022-03-02 19:16", item = 32528}, -- Shushi : Blessed Band of Karabor
    {player = 10, timestamp = "2022-03-02 19:48", item = 32260}, -- Jwarrior : Choker of Endless Nightmares
    {player =  6, timestamp = "2022-03-02 20:10", item = 32273}, -- Eclipce : Amice of Brilliant Light
    {player = 21, timestamp = "2022-03-02 20:14", item = 32251}, -- Stolnikova : Wraps of Precise Flight
    {player = 24, timestamp = "2022-03-02 20:14", item = 32232}, -- Vrilya : Eternium Shell Bracers
    {player =  5, timestamp = "2022-03-02 20:17", item = 32240}, -- Breadshadow : Guise of the Tidal Lurker
    {player =  1, timestamp = "2022-03-02 20:18", item = 34011}, -- Animelove : Illidari Runeshield
    {player = 22, timestamp = "2022-03-02 22:06", item = 32323}, -- Tidanbo : Shadowmoon Destroyer's Drape
    {player =  6, timestamp = "2022-03-02 22:10", item = 32363}, -- Eclipce : Naaru-Blessed Life Rod
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
