local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Airness",
    [ 2] = "Vrilya",
    [ 3] = "Antche",
    [ 4] = "Astorah",
    [ 5] = "Bagts",
    [ 6] = "Blixlock",
    [ 7] = "Breadshadow",
    [ 8] = "Eclipce",
    [ 9] = "Fauxxy",
    [10] = "Frisk",
    [11] = "Gafr",
    [12] = "Hánna",
    [13] = "Komsika",
    [14] = "Lamishra",
    [15] = "Luandra",
    [16] = "Maclourion",
    [17] = "Misandri",
    [18] = "Mygrain",
    [19] = "Palypoes",
    [20] = "Podra",
    [21] = "Razolea",
    [22] = "Tidanbo",
    [23] = "Vende",
    [24] = "Volrik",
    [25] = "Zofija",
  },
  kills = {
    {boss = 900, timestamp = "2022-03-03 21:00", players = {1,2,3,4,5,6,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 624, timestamp = "2022-03-03 21:08", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 628, timestamp = "2022-03-03 21:31", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 625, timestamp = "2022-03-03 22:09", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 626, timestamp = "2022-03-03 22:31", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 627, timestamp = "2022-03-03 22:46", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 901, timestamp = "2022-03-03 22:48", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player = 22, timestamp = "2022-03-03 21:37", item = 30057}, -- Tidanbo : Bracers of Eradication
    {player =  5, timestamp = "2022-03-03 21:37", item = 30244}, -- Bagts : Helm of the Vanquished Hero
    {player =  9, timestamp = "2022-03-03 21:37", item = 30107}, -- Fauxxy :Vestments of the Sea-Witch
    {player =  8, timestamp = "2022-03-03 21:37", item = 30107}, -- Eclipce :Leggings of the Vanquished Defender
    {player = 19, timestamp = "2022-03-03 21:37", item = 30106}, -- Palypoes : Belt of one hundred
    {player = 19, timestamp = "2022-03-03 21:37", item = 30627}, -- Palypoes : Tsunami Talisman
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
