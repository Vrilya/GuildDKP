local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Astorah",
    [ 3] = "Cainei",
    [ 4] = "Chymical",
    [ 5] = "Ciormola",
    [ 6] = "Crittney",
    [ 7] = "Cryones",
    [ 8] = "Hánna",
    [ 9] = "Klopthet",
    [10] = "Komsika",
    [11] = "Krepe",
    [12] = "Kyera",
    [13] = "Lamishra",
    [14] = "Maclourion",
    [15] = "Miggit",
    [16] = "Misandri",
    [17] = "Mortimati",
    [18] = "Mygrain",
    [19] = "Môrci",
    [20] = "Nowatah",
    [21] = "Philthewise",
    [22] = "Roguinaa",
    [23] = "Räkpaj",
    [24] = "Saray",
    [25] = "Silverpond",
    [26] = "Tidanbo",
    [27] = "Tierlin",
    [28] = "Twodaggers",
    [29] = "Vrilya",
    [30] = "Zofija",
  },
  kills = {
    {boss = 900, timestamp = "2022-03-06 19:24", players = {1,2,5,6,8,11,13,14,16,17,18,19,21,22,23,24,25,26,28,29,30}},
    {boss = 649, timestamp = "2022-03-06 19:35", players = {1,2,5,6,8,11,13,14,16,17,18,19,21,22,23,24,25,26,28,29,30}},
    {boss = 650, timestamp = "2022-03-06 19:47", players = {1,2,5,6,8,11,13,14,16,17,18,19,21,22,23,24,25,26,28,29,30}},
	{boss = 901, timestamp = "2022-03-06 21:26", players = {1,2,5,6,8,11,13,14,16,17,18,19,21,22,23,24,25,26,28,29,30}},
  },
  drops = {
    },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
