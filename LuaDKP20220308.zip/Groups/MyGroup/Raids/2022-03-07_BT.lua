local _, ADDON = ...

------------------------------------------------------------

local raid = {
  players = {
    [ 0] = "?",
    [ 1] = "Animelove",
    [ 2] = "Bagts",
    [ 3] = "Bobiko",
    [ 4] = "Breadshadow",
    [ 5] = "Eclipce",
    [ 6] = "Ejectoseato",
    [ 7] = "Fauxxy",
    [ 8] = "Jeani",
    [ 9] = "Jwarrior",
    [10] = "Lamishra",
    [11] = "Locktorius",
    [12] = "Luandra",
    [13] = "Maclourion",
    [14] = "Malgeth",
    [15] = "Misandri",
    [16] = "Mygrain",
    [17] = "Mythria",
    [18] = "Palypoes",
    [19] = "Paynz",
    [20] = "Räkpaj",
    [21] = "Saray",
    [22] = "Stolnikova",
    [23] = "Tidanbo",
    [24] = "Volrik",
    [25] = "Vrilya",
  },
  kills = {
    {boss = 904, timestamp = "2022-03-07 19:00", players = {1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 605, timestamp = "2022-03-07 19:26", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 607, timestamp = "2022-03-07 19:56", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 608, timestamp = "2022-03-07 20:33", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 906, timestamp = "2022-03-07 20:34", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 907, timestamp = "2022-03-07 21:30", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
    {boss = 905, timestamp = "2022-03-07 22:00", players = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25}},
  },
  drops = {
    {player =  4, timestamp = "2022-03-07 19:27", item = 32344}, -- Breadshadow : Staff of Immaculate Recovery
    {player =  9, timestamp = "2022-03-07 19:28", item = 32335}, -- Jwarrior : Unstoppable Aggressor's Ring
    {player = 25, timestamp = "2022-03-07 19:58", item = 32369}, -- Vrilya : Blade of Savagery
    {player = 11, timestamp = "2022-03-07 19:59", item = 31101}, -- Locktorius : Pauldrons of the Forgotten Conqueror
    {player =  7, timestamp = "2022-03-07 20:00", item = 31102}, -- Fauxxy : Pauldrons of the Forgotten Vanquisher
    {player = 25, timestamp = "2022-03-07 20:41", item = 31100}, -- Vrilya : Leggings of the Forgotten Protector
    {player = 10, timestamp = "2022-03-07 20:43", item = 31100}, -- Lamishra : Leggings of the Forgotten Protector
    {player = 22, timestamp = "2022-03-07 20:44", item = 32376}, -- Stolnikova : Forest Prowler's Helm
  },
}

------------------------------------------------------------

-- export raid
ADDON.InitGroup.Raids = ADDON.InitGroup.Raids or {}
table.insert(ADDON.InitGroup.Raids, raid)
